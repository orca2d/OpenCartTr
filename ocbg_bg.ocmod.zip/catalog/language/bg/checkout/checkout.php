<?php
// Heading
$_['heading_title'] = 'Поръчка';

// Text
$_['text_cart'] = 'Кошница';
