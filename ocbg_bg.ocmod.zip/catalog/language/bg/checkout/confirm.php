<?php
// Text
$_['text_model']        = 'Модел';
$_['text_subscription'] = 'Абонамент';
$_['text_points']       = 'Наградни точки';

// Column
$_['column_product']  = 'Продукт';
$_['column_quantity'] = 'К-во';
$_['column_price']    = 'Ед. цена';
$_['column_total']    = 'Общо';