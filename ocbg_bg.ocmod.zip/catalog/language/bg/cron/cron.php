<?php
// Text
$_['text_success'] = 'Стартирахте %s cron задача!';

// Error
$_['error_permission'] = 'Внимание: Нямате права да промените тази cron задача!';
