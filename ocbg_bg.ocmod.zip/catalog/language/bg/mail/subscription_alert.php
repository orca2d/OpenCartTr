<?php
// Text
$_['text_subject']             = '%s - Поръчка %s - Отменен абонаментен план';
$_['text_received']            = 'Абонамеен план беше отменен.';
$_['text_orders_id']           = 'Поръчка:';
$_['text_subscription_id']     = 'Номер на абонаментния план';
$_['text_date_added']          = 'Дата на добавяне:';
$_['text_subscription_status'] = 'Статус:';
$_['text_comment']             = 'Коментарите към вашия абонаментен план:';
$_['text_canceled']            = 'Готово: Абонаментният план беше отменен!';
