<?php
// Text
$_['text_subject']      = '%s - Поръчка %s';
$_['text_received']     = 'Получихте нова поръчка.';
$_['text_order_id']     = 'Номер:';
$_['text_date_added']   = 'Дата на добавяне:';
$_['text_order_status'] = 'Статус на поръчката:';
$_['text_product']      = 'Продукти:';
$_['text_total']        = 'Общо:';
$_['text_comment']      = 'Коментари към поръчката:';
