<?php
// Text
$_['text_subject']  = '%s - Отзив за продукт';
$_['text_waiting']  = 'Има нов отзив за продукт, чакащ одобрение.';
$_['text_product']  = 'Продукт:';
$_['text_reviewer'] = 'Отзив от:';
$_['text_rating']   = 'Оценка:';
$_['text_review']   = 'Текст на отзива:';
