<?php
// Heading
$_['heading_title'] = 'Контакти';

// Text
$_['text_location']  = 'Адреси';
$_['text_store']     = 'Магазини';
$_['text_contact']   = 'Форма за връзка с нас';
$_['text_address']   = 'Адрес';
$_['text_telephone'] = 'Телефон';
$_['text_open']      = 'Работно време';
$_['text_comment']   = 'Въпрос';
$_['text_message']   = '<p>Вашият въпрос беше успешно изпратен!</p>';

// Entry
$_['entry_name']    = 'Име и фамилия';
$_['entry_email']   = 'E-Mail адрес';
$_['entry_enquiry'] = 'Въпрос';

// Email
$_['email_subject'] = 'Въпрос %s';

// Errors
$_['error_name']    = 'Името трябва да бъде между 3 и 32 символа!';
$_['error_email']   = 'E-Mail адресът не изглежда валиден!';
$_['error_enquiry'] = 'Запитването трябва да бъде между 10 и 3000 символа!';
