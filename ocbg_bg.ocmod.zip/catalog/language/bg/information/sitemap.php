<?php
// Heading
$_['heading_title'] = 'Карта на сайта';

// Text
$_['text_special']     = 'Промоции';
$_['text_account']     = 'Моят профил';
$_['text_edit']        = 'Редактирай';
$_['text_password']    = 'Парола';
$_['text_address']     = 'Моите адреси';
$_['text_history']     = 'История на поръчките';
$_['text_download']    = 'Изтегления';
$_['text_cart']        = 'Количка';
$_['text_checkout']    = 'Поръчай';
$_['text_search']      = 'Търсене';
$_['text_information'] = 'Информация';
$_['text_contact']     = 'Контакти';
