<?php
// Heading
$_['heading_title'] = 'Блог';

// Text
$_['text_refine']          = 'Подробно търсене';
$_['text_all']             = 'Всички';
$_['text_blog']            = 'Блог';
$_['text_by']              = 'От';
$_['text_tags']            = 'Тагове:';
$_['text_comment']         = 'коментари';
$_['text_no_results']      = 'Няма добавени статии.';
$_['text_sort']            = 'Сортирай по';
$_['text_rating_asc']      = 'Отзиви (Най-ниски)';
$_['text_rating_desc']     = 'Отзиви (Най-високи)';
$_['text_date_added_asc']  = 'Дата на добавяне (Най-стари)';
$_['text_date_added_desc'] = 'Дата на добавяне (Най-нови)';

// Entry
$_['entry_search'] = 'Търсене';

// Button
$_['button_continue'] = 'Продължи';
