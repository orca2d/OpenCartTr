<?php
// Heading
$_['heading_title'] = 'Профилактика';

// Text
$_['text_maintenance'] = 'Профилактика';
$_['text_message']     = '<h1 style="text-align:center;">В момента извършваме планирана профилактика. <br/>Ще сме налиния възможно най скоро.</h1>';
