<?php
// Text
$_['text_wishlist']      = 'Любими (%s)';
$_['text_shopping_cart'] = 'Количка';
$_['text_account']       = 'Моят профил';
$_['text_register']      = 'Регистрация';
$_['text_login']         = 'Вход';
$_['text_order']         = 'История на поръчките';
$_['text_transaction']   = 'Транзакции';
$_['text_download']      = 'Изтегляния';
$_['text_logout']        = 'Изход';
$_['text_checkout']      = 'Поръчай';
