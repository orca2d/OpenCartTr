<?php
// Text
$_['text_items']                 = '%s продукта(и) - %s';
$_['text_points']                = 'Бонус точки';
$_['text_subscription']          = 'Абонамент';
$_['text_subscription_duration'] = '%s на всеки %d %s(%s) за %d плащане(я)';
$_['text_subscription_cancel']   = '%s на всеки %d %s(%s) докато не бъде отказано';
$_['text_day']                   = 'ден';
$_['text_week']                  = 'седмица';
$_['text_semi_month']            = 'половин месец';
$_['text_month']                 = 'месец';
$_['text_year']                  = 'година';
$_['text_no_results']            = 'Вашата количка е празна!';
$_['text_cart']                  = 'Преглед на количката';
$_['text_checkout']              = 'Поръчай';

// Error
$_['error_product'] = 'Внимание: Продуктът не може да бъде намерен!';