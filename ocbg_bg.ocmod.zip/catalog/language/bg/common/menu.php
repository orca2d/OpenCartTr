<?php
// Text
$_['text_category'] = 'Продукти';
$_['text_all']      = 'Всички в ';
