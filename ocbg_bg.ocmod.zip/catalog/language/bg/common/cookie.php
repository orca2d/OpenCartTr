<?php
// Text
$_['text_success'] = 'Благодарим Ви за избора!';
$_['text_cookie']  = 'Този уебсайт използва бисквитки. Виж повече <a href="%s" class="alert-link modal-link">тук</a>.';

// Buttons
$_['button_agree']    = 'Приемам';
$_['button_disagree'] = 'Отказвам';
