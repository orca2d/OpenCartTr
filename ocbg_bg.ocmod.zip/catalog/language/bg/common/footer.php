<?php
// Text
$_['text_information']  = 'Информация';
$_['text_blog']         = 'Блог';
$_['text_service']      = 'Обслужване на клиенти';
$_['text_extra']        = 'Допълнителни';
$_['text_contact']      = 'Контакти';
$_['text_return']       = 'Връщане';
$_['text_sitemap']      = 'Карта на сайта';
$_['text_gdpr']         = 'GDPR';
$_['text_manufacturer'] = 'Марки';
$_['text_affiliate']    = 'Партньори';
$_['text_special']      = 'Промоции';
$_['text_account']      = 'Моят профил';
$_['text_order']        = 'История на поръчките';
$_['text_wishlist']     = 'Любими';
$_['text_newsletter']   = 'Бюлетин';
$_['text_powered']      = 'Изработка на онлайн магазин <a href="https://opencartbulgaria.com" target="_blank">OpenCart България</a><br/> %s &copy; %s';