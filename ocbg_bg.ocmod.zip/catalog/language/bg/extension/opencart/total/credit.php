<?php
// Text
$_['text_credit']   = 'Кредит';
$_['text_order_id'] = 'Номер: #%s';
