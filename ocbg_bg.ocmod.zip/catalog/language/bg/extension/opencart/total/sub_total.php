<?php
// Text
$_['text_sub_total'] = 'Междинна сума';
