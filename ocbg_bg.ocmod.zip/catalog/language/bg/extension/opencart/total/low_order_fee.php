<?php
// Text
$_['text_low_order_fee'] = 'Такса за ниска стойност на поръчка';
