<?php
// Text
$_['text_coupon']  = 'Код за отстъпка (%s)';