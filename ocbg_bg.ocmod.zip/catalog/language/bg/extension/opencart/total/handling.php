<?php
// Text
$_['text_handling'] = 'Такса за обработка';
