<?php
// Text
$_['text_reward']   = 'Наградни точки (%s)';
$_['text_order_id'] = 'Номер: #%s';