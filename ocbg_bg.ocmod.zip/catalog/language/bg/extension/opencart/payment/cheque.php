<?php
// Heading
$_['heading_title'] = 'Чек';

// Text
$_['text_instruction'] = 'Инструкции за плащане с чек';
$_['text_payable']     = 'Платено на: ';
$_['text_address']     = 'Изпрати до: ';
$_['text_payment']     = 'Поръчката Ви няма да бъде изпратена, докато не получим плащането.';
