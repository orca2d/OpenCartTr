<?php
// Heading
$_['heading_title'] = 'Безплатна доставка';

// Text
$_['text_description'] = 'Безплатна доставка';
