<?php
// Heading
$_['heading_title'] = 'Доставка базирана на тегло';

// Text
$_['text_weight'] = 'Тегло:';
