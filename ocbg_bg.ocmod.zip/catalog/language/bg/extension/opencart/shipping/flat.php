<?php
// Heading
$_['heading_title'] = 'Фиксирана доставка';

// Text
$_['text_description'] = 'Фиксирана цена за доставка';
