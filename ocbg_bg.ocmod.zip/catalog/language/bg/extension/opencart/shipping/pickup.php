<?php
// Heading
$_['heading_title'] = 'Взимане от наш обект';

// Text
$_['text_description'] = 'Взимане от наш обект';
