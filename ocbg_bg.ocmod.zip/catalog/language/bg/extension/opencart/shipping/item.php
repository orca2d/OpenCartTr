<?php
// Heading
$_['heading_title'] = 'Доставка на продукт';

// Text
$_['text_description'] = 'Цена за доставка на продукт';
