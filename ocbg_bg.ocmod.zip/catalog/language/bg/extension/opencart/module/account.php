<?php
// Heading
$_['heading_title'] = 'Моят профил';

// Text
$_['text_register']     = 'Регистрация';
$_['text_login']        = 'Вход';
$_['text_logout']       = 'Изход';
$_['text_forgotten']    = 'Забравена парола';
$_['text_account']      = 'Моят профил';
$_['text_edit']         = 'Редактирай профил';
$_['text_password']     = 'Парола';
$_['text_address']      = 'Моите адреси';
$_['text_wishlist']     = 'Любими продукти';
$_['text_order']        = 'Предишни поръчки';
$_['text_download']     = 'Изтегляния';
$_['text_reward']       = 'Наградни точки';
$_['text_return']       = 'Върнати продукти';
$_['text_transaction']  = 'Транзакции';
$_['text_newsletter']   = 'Бюлетин';
$_['text_subscription'] = 'Абонаментни планове';
