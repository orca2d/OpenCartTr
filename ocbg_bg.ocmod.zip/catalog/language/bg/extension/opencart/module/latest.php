<?php
// Heading
$_['heading_title'] = 'Нови продукти';
