<?php
// Heading
$_['heading_title'] = 'Информация';

// Text
$_['text_contact'] = 'Контакти';
$_['text_sitemap'] = 'Карта на сайта';
