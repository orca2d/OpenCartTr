<?php
// Heading
$_['heading_title'] = 'Бюлетин';

// Text
$_['text_account']    = 'Профил';
$_['text_newsletter'] = 'Бюлетин';
$_['text_success']    = 'Готово: Вашият абонамент за бюлетина ни беше променен успешно!';

// Entry
$_['entry_newsletter'] = 'Запиши се';
