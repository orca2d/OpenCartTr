<?php
// Heading
$_['heading_title'] = 'Вашите наградни точки';

// Column
$_['column_date_added']  = 'Дата на добавяне';
$_['column_description'] = 'Описание';
$_['column_points']      = 'Наградни точки';

// Text
$_['text_account']    = 'Профил';
$_['text_reward']     = 'Наградни точки';
$_['text_total']      = 'Общият ви брой наградни точки е:';
$_['text_no_results'] = 'Нямате наградни точки!';
