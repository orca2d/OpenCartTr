<?php
// Heading
$_['heading_title'] = 'Моят профил';

// Text
$_['text_account']        = 'Профил';
$_['text_my_account']     = 'Моят профил';
$_['text_my_orders']      = 'Моите поръчки';
$_['text_my_affiliate']   = 'Афилиейт профил';
$_['text_my_newsletter']  = 'Бюлетин';
$_['text_edit']           = 'Редактиране на профила';
$_['text_password']       = 'Промяна на паролата';
$_['text_address']        = 'Редактиране на адресите';
$_['text_payment_method'] = 'Запазени методи на плащане';
$_['text_wishlist']       = 'Редактиране на любими';
$_['text_order']          = 'Историята на поръчките';
$_['text_subscription']   = 'Абонаментни планове';
$_['text_download']       = 'Изтегляния';
$_['text_reward']         = 'Бонус точки';
$_['text_return']         = 'Заявките за връщане';
$_['text_transaction']    = 'Вашите плащания';
$_['text_newsletter']     = 'Абониране/отписване от бюлетина';
$_['text_transactions']   = 'Плащания';
$_['text_affiliate_add']  = 'Регистрация на афилиейт профил';
$_['text_affiliate_edit'] = 'Редактиране на афилиейт профил';
$_['text_tracking']       = 'Персонален код за афилиейт проследяване';
