<?php
// Heading
$_['heading_title'] = 'Афилиейт';

// Text
$_['text_account']      = 'Профил';
$_['text_affiliate']    = 'Афилиейт';
$_['text_my_affiliate'] = 'Моят Афилиейт профил';
$_['text_payment']      = 'Информация за плащане';
$_['text_cheque']       = 'Чек';
$_['text_paypal']       = 'PayPal';
$_['text_bank']         = 'Плащане по банка';
$_['text_success']      = 'Готово: Афилиейт партньорският акаунт е променен.';
$_['text_agree']        = 'Прочетох и съм съгласен с <a href="%s" class="modal-link"><b>%s</b></a>';

// Entry
$_['entry_company']             = 'Фирма';
$_['entry_website']             = 'Уебсайт';
$_['entry_tax']                 = 'Данъчен номер';
$_['entry_payment_method']      = 'Начин на плащане';
$_['entry_cheque']              = 'Име на получател на чек';
$_['entry_paypal']              = 'PayPal имейл';
$_['entry_bank_name']           = 'Банка';
$_['entry_bank_branch_number']  = 'ABA/BSB номер (Номер на клон)';
$_['entry_bank_swift_code']     = 'SWIFT код';
$_['entry_bank_account_name']   = 'Име на титуляр';
$_['entry_bank_account_number'] = 'Номер на банкова сметка (IBAN)';

// Error
$_['error_token']               = 'Внимание: Невалиден код за афилиейт партньор!';
$_['error_agree']               = 'Внимание: Трябва да се съгласите с %s!';
$_['error_payment_method']      = 'Необходим е начин на плащане!';
$_['error_cheque']              = 'Необходимo е име на получател на чек!';
$_['error_paypal']              = 'Имейл адресът на PayPal изглежда не е валиден!';
$_['error_bank_account_name']   = 'Необходимо е име на титуляр!';
$_['error_bank_account_number'] = 'Необходим е номер на банкова сметка!';
$_['error_custom_field']        = '%s е задължително поле!';
$_['error_regex']               = '%s не е валидна стойност!';