<?php
// Heading
$_['heading_title'] = 'Изтегляния';

// Text
$_['text_account']    = 'Профил';
$_['text_downloads']  = 'Изтегляния';
$_['text_no_results'] = 'Досега не сте поръчвали продукти, които може да се изтеглят!';

// Column
$_['column_order_id']   = 'Номер';
$_['column_name']       = 'Име';
$_['column_size']       = 'Размер';
$_['column_date_added'] = 'Дата на добавяне';

// Error
$_['error_not_found']    = 'Грешка: Не може да намерим файл %s !';
$_['error_headers_sent'] = 'Грешка: Заглавията вече са изпратени!';
