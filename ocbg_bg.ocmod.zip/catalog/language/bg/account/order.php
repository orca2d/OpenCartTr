<?php
// Heading
$_['heading_title'] = 'Поръчки';

// Text
$_['text_account']               = 'Профил';
$_['text_order']                 = 'Поръчка #%s';
$_['text_order_id']              = 'Поръчка';
$_['text_invoice_no']            = 'Разписка №';
$_['text_tbc']                   = 'TBC';
$_['text_shipping_address']      = 'Адрес за доставка';
$_['text_payment_address']       = 'Адрес за плащане';
$_['text_shipping_method']       = 'Начин на доставка';
$_['text_payment_method']        = 'Начин на плащане';
$_['text_model']                 = 'Модел';
$_['text_points']                = 'Наградни точки';
$_['text_subscription']          = 'Абонаментен план';
$_['text_subscription_trial']    = '%s на всеки %d %s(а) за %d плащане(я), след това ';
$_['text_subscription_duration'] = '%s на всеки %d %s(а) за %d плащане(я)';
$_['text_subscription_cancel']   = '%s на всеки %d %s(а) докато не бъде отказан';
$_['text_day']                   = 'ден';
$_['text_week']                  = 'седмица';
$_['text_semi_month']            = 'половин месец';
$_['text_month']                 = 'месец';
$_['text_year']                  = 'година';
$_['text_date_next']             = 'Следваща дата';
$_['text_remaining']             = 'Оставащи';
$_['text_comment']               = 'Коментари за поръчката';
$_['text_history']               = 'История на поръчката';
$_['text_success']               = 'Готово: Добавихте <a href="%s">%s</a> в <a href="%s">количката</a>!';
$_['text_no_results']            = 'Все още нямате направени поръчки!';

// Column
$_['column_order_id']      = 'Номер';
$_['column_customer']      = 'Клиент';
$_['column_product']       = 'Брой продукти';
$_['column_product_total'] = 'Брой продукти';
$_['column_status']        = 'Статус';
$_['column_total']         = 'Общо';
$_['column_date_added']    = 'Дата на добавяне';
$_['column_quantity']      = 'Количество';
$_['column_price']         = 'Цена';
$_['column_comment']       = 'Коментар';
$_['column_action']        = 'Действие';

// Error
$_['error_reorder'] = '%s в момента не може да се поръча повторно.';
