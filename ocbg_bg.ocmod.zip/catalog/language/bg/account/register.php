<?php
// Heading
$_['heading_title'] = 'Регистрация';

// Text
$_['text_account']         = 'Профил';
$_['text_register']        = 'Регистрация';
$_['text_account_already'] = 'Ако имате профил, моля влезте в <a href="%s"> за да се логнете</a>.';
$_['text_your_details']    = 'Вашите данни';
$_['text_newsletter']      = 'Бюлетин';
$_['text_your_password']   = 'Вашата парола';
$_['text_agree']           = 'Прочетох и се съгласявам с <a href="%s" class="modal-link"><b>%s</b></a>';

// Entry
$_['entry_customer_group'] = 'Клиентска група';
$_['entry_firstname']      = 'Име';
$_['entry_lastname']       = 'Фамилия';
$_['entry_email']          = 'Имейл адрес';
$_['entry_telephone']      = 'Телефон';
$_['entry_newsletter']     = 'Запиши се';
$_['entry_password']       = 'Парола';
$_['entry_confirm']        = 'Потвръждение на парола';

// Error
$_['error_token']          = 'Внимание: Невалиден регистрационен токен!';
$_['error_exists']         = 'Внимание: Имейл адресът вече е регистриран!';
$_['error_customer_group'] = 'Групата клиенти изглежда не е валидна!';
$_['error_firstname']      = 'Името трябва да бъде между 1 и 32 символа!';
$_['error_lastname']       = 'Фамилията трябва да бъде между 1 и 32 символа!';
$_['error_email']          = 'Имейл адресът не е валиден!';
$_['error_telephone']      = 'Телефонният номер трябва да бъде между 3 и 32 символа!';
$_['error_custom_field']   = '%s е задължително поле!';
$_['error_regex']          = '%s не е валидна стойност!';
$_['error_password']       = 'Паролата трябва да бъде между 6 и 20 символа!';
$_['error_agree']          = 'Внимание: Трябва да се съгласите с %s!';
