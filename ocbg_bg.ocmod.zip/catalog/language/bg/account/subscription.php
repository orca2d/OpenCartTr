<?php
// Heading
$_['heading_title'] = 'Абонаментни планове';

// Text
$_['text_account']               = 'Профил';
$_['text_success']               = 'Вашият абонамент е успешно отменен!';
$_['text_subscription']          = 'Абонаментен план #%s';
$_['text_subscription_id']       = 'Номер на абонаментния план';
$_['text_order_id']              = 'Номер';
$_['text_shipping_address']      = 'Адрес за доставка';
$_['text_shipping_method']       = 'Начин на доставка';
$_['text_payment_address']       = 'Адрес за плащане';
$_['text_payment_method']        = 'Начин на плащане';
$_['text_model']                 = 'Модел';
$_['text_subscription_plan']     = 'Абонаментен план';
$_['text_subscription_trial']    = '%s на всеки %d %s(а) за %d плащане(я), след това ';
$_['text_subscription_duration'] = '%s на всеки %d %s(а) за %d плащане(я)';
$_['text_subscription_cancel']   = '%s на всеки %d %s(а) докато не бъде отказан';
$_['text_day']                   = 'ден';
$_['text_week']                  = 'седмица';
$_['text_semi_month']            = 'половин месец';
$_['text_month']                 = 'месец';
$_['text_year']                  = 'година';
$_['text_quantity']              = 'Количество';
$_['text_date_next']             = 'Следваща дата';
$_['text_remaining']             = 'Оставащи';
$_['text_history']               = 'История на плана';
$_['text_order']                 = 'История на поръчката';
$_['text_no_subscription']       = 'Не са намерени абонаменти!';
// Column
$_['column_subscription_id'] = 'Номер на абонаментния план';
$_['column_product']         = 'Продукт';
$_['column_product_total']   = 'Брой продукти';
$_['column_description']     = 'Описание';
$_['column_order_id']        = 'Номер на поръчка';
$_['column_status']          = 'Статус';
$_['column_quantity']        = 'Количество';
$_['column_trial_price']     = 'Цена на пробния период';
$_['column_price']           = 'Цена';
$_['column_total']           = 'Общо';
$_['column_comment']         = 'Коментар';
$_['column_date_added']      = 'Дата на добавяне';

// Button
$_['button_cancel'] = 'Отмени абонамент';

// Error
$_['error_subscription'] = 'Абонаментът не може да бъде намерен!';
$_['error_duration']     = 'Абонаментът не може да бъде отменен, докато не бъдат изпълнени още %s поръчки!';
$_['error_canceled']     = 'Абонаментът вече е отменен!';