<?php
// Heading
$_['heading_title'] = 'Начини на плащане';

// Text
$_['text_account']    = 'Профил';
$_['text_no_results'] = 'Нямате въведени начини на плащане в профила си.';
