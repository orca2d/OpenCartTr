<?php
// Heading
$_['heading_title'] = 'Вашите транзакции';

// Column
$_['column_date_added']  = 'Дата на добавяне';
$_['column_description'] = 'Описание';
$_['column_amount']      = 'Сума (%s)';

// Text
$_['text_account']     = 'Провил';
$_['text_transaction'] = 'Вашите транзакции';
$_['text_total']       = 'Вашият баланс е:';
$_['text_no_results']  = 'Нямате транзакции!';
