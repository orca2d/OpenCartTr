<?php
// Heading
$_['heading_title'] = 'Търсене';
$_['heading_tag']   = 'Етикети - ';

// Text
$_['text_search']       = 'Продукти, отговарящи на критериите за търсене';
$_['text_keyword']      = 'Ключови думи';
$_['text_category']     = 'Всички категории';
$_['text_sub_category'] = 'Търсене в подкатегории';
$_['text_no_results']   = 'Няма продукт, който да съответства на критериите за търсене.';
$_['text_compare']      = 'Сравнение на продукти (%s)';
$_['text_sort']         = 'Сортирай по';
$_['text_default']      = 'По подразбиране';
$_['text_name_asc']     = 'Име (А-Я)';
$_['text_name_desc']    = 'Име (Я-А)';
$_['text_price_asc']    = 'Цена (Най-висока)';
$_['text_price_desc']   = 'Цена (Най-ниска)';
$_['text_rating_asc']   = 'Оценки (Най-нисъки)';
$_['text_rating_desc']  = 'Оценки (Най-високи)';
$_['text_model_asc']    = 'Модел (А-Я)';
$_['text_model_desc']   = 'Модел (Я-А)';
$_['text_limit']        = 'Покажи';

// Entry
$_['entry_search']      = 'Критерии за търсене';
$_['entry_description'] = 'Търсене в описание на продукта';
