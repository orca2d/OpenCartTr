<?php
// Heading
$_['heading_title'] = 'Промоции';

// Text
$_['text_no_results']  = 'Няма налични продукти в промоции.';
$_['text_compare']     = 'Сравнение на продукт (%s)';
$_['text_sort']        = 'Сортирай по';
$_['text_default']     = 'По подразбиране';
$_['text_name_asc']    = 'Име (А-Я)';
$_['text_name_desc']   = 'Име (Я-А)';
$_['text_price_asc']   = 'Цена (Ниска &gt; Висока)';
$_['text_price_desc']  = 'Цена (Висока &gt; Ниска)';
$_['text_rating_asc']  = 'Оценка (Най-ниска)';
$_['text_rating_desc'] = 'Оценка (Най-висока)';
$_['text_model_asc']   = 'Модел (А-Я)';
$_['text_model_desc']  = 'Модел (Я-А)';
$_['text_limit']       = 'Покажи';
