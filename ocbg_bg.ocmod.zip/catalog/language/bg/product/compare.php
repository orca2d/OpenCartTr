<?php
// Heading
$_['heading_title'] = 'Сравняване на продукти';

// Text
$_['text_product']      = 'Детайли за продукта';
$_['text_name']         = 'Продукт';
$_['text_image']        = 'Снимка';
$_['text_price']        = 'Цена';
$_['text_model']        = 'Модел';
$_['text_manufacturer'] = 'Марка';
$_['text_availability'] = 'Наличност';
$_['text_rating']       = 'Оценка';
$_['text_reviews']      = 'Базирано на %s отзиви.';
$_['text_summary']      = 'Обобщение';
$_['text_weight']       = 'Тегло';
$_['text_dimension']    = 'Размери (ДxШxВ)';
$_['text_compare']      = 'Сравнение на продукти (%s)';
$_['text_success']      = 'Готово: Добавихте <a href="%s">%s</a> към <a href="%s">сравнение на продукти</a>!';
$_['text_remove']       = 'Готово: Променихте сравнението на продукти!';
$_['text_no_results']   = 'Не сте избрали продукти за сравнение.';

// Error
$_['error_product'] = 'Внимание: Продукта не е намерен!';
