<?php
// Heading
$_['heading_title'] = 'Марки';

// Text
$_['text_brand']       = 'Марка';
$_['text_index']       = 'Всички марки:';
$_['text_no_results']  = 'Няма продукти от тази марка.';
$_['text_compare']     = 'Сравенение на продукти (%s)';
$_['text_sort']        = 'Сортирай по';
$_['text_default']     = 'По подразбиране';
$_['text_name_asc']    = 'Име (А-Я)';
$_['text_name_desc']   = 'Име (Я-А)';
$_['text_price_asc']   = 'Цена (Ниска &gt; Висока)';
$_['text_price_desc']  = 'Цена (Висока &gt; Ниска)';
$_['text_rating_asc']  = 'Оценки (Най-ниски)';
$_['text_rating_desc'] = 'Оценки (Най-високи)';
$_['text_model_asc']   = 'Модел (А-Я)';
$_['text_model_desc']  = 'Модел (Я-А)';
$_['text_limit']       = 'Покажи';
