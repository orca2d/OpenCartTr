<?php
// Text
$_['text_search']                = 'Търсене';
$_['text_brand']                 = 'Марка';
$_['text_manufacturer']          = 'Марка:';
$_['text_model']                 = 'Кат. номер:';
$_['text_reward']                = 'Наградни точки:';
$_['text_points']                = 'Цена в наградни точки:';
$_['text_stock']                 = 'Наличност:';
$_['text_tax']                   = 'Без ДДС:';
$_['text_discount']              = ' бр. или повече за ';
$_['text_option']                = 'Варианти';
$_['text_minimum']               = 'Този продукт има изискване за мин. к-во от %s';
$_['text_reviews']               = '%s отзива';
$_['text_write']                 = 'Напишете отзив';
$_['text_login']                 = 'Моля, <a href="%s">влезте</a> или <a href="%s"> се регистрирайте</a>, за да оставите отзив.';
$_['text_tags']                  = 'Етикети:';
$_['text_subscription']          = 'Абонамент';
$_['text_subscription_duration'] = '%s на всеки %d %s(%s) за %d плащане(я)';
$_['text_subscription_cancel']   = '%s на всеки %d %s(%s) докато не бъде отказано';
$_['text_day']                   = 'ден';
$_['text_week']                  = 'седмица';
$_['text_semi_month']            = 'половин месец';
$_['text_month']                 = 'месец';
$_['text_year']                  = 'година';

// Entry
$_['entry_qty']    = 'К-во';
$_['entry_rating'] = 'Оценка';

// Tabs
$_['tab_description'] = 'Описание';
$_['tab_attribute']   = 'Характеристики';
$_['tab_review']      = 'Отзиви (%s)';
