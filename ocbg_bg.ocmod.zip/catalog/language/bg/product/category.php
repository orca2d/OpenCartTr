<?php
// Text
$_['text_refine']      = 'Подкатегории';
$_['text_product']     = 'Продукти';
$_['text_no_results']  = 'В тази категория все още няма продукти.';
$_['text_compare']     = 'Сравни (%s)';
$_['text_sort']        = 'Сортирай по';
$_['text_default']     = 'По подразбиране';
$_['text_name_asc']    = 'Име (А-Я)';
$_['text_name_desc']   = 'Име (Я-А)';
$_['text_price_asc']   = 'Цена (Ниска &gt; Висока)';
$_['text_price_desc']  = 'Цена (Висока &gt; Ниска)';
$_['text_rating_asc']  = 'Отзиви (Най-ниски)';
$_['text_rating_desc'] = 'Отзиви (Най-високи)';
$_['text_model_asc']   = 'Модел (А - Я)';
$_['text_model_desc']  = 'Модел (Я - А)';
$_['text_limit']       = 'Покажи';
