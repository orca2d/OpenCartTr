<?php
$_['text_related'] = 'Свързани продукти';