<?php
// Text
$_['text_price'] = 'Цена:';
$_['text_tax']   = 'без ДДС:';
