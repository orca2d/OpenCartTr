<?php
// Heading
$_['heading_title'] = 'APIs';

// Text
$_['text_success'] = 'Готово: Успешно променихте APIs!';
$_['text_list']    = 'Списък с API';
$_['text_add']     = 'Добави API';
$_['text_edit']    = 'Редактирай API';
$_['text_ip']      = 'По-долу можете да създадете списък с IP адреси, разрешени за достъп до API-то. Вашият текущ IP адрес е %s';
$_['text_history'] = 'История';

// Column
$_['column_username']   = 'API потребител';
$_['column_status']     = 'Статус';
$_['column_ip']         = 'IP адрес';
$_['column_call']       = 'Обаждане';
$_['column_date_added'] = 'Дата на добавяне';
$_['column_action']     = 'Действие';

// Entry
$_['entry_username'] = 'API потребител';
$_['entry_key']      = 'API ключ';
$_['entry_status']   = 'Статус';
$_['entry_ip']       = 'IP адрес';

// Error
$_['error_permission'] = 'Внимание: Нямате права да променяте APIs!';
$_['error_username']   = 'Потребителското име за API трябва да бъде между 3 и 20 символа!';
$_['error_key']        = 'API ключът трябва да бъде между 64 и 256 символа!';
$_['error_ip']         = 'Трябва да добавите поне един IP адрес към разрешения списък!';
