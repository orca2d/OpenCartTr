<?php
// Heading
$_['heading_title'] = 'Еmail маркетинг';

// Text
$_['text_mail']           = 'Изпрати имейли на клиентите';
$_['text_success']        = 'Вашето съобщение е изпратено успешно!';
$_['text_sent']           = 'Вашето събощение е успешно изпратено до %s на %s от %s получателя!';
$_['text_default']        = 'По подразбиране';
$_['text_newsletter']     = 'Всички записали се за бюлетина';
$_['text_customer_all']   = 'Всички клиенти';
$_['text_customer_group'] = 'Клиентска група';
$_['text_customer']       = 'Клиенти';
$_['text_affiliate_all']  = 'Всички афилиейт профили';
$_['text_affiliate']      = 'Афилиейт партньор';
$_['text_product']        = 'Продукти';

// Entry
$_['entry_store']          = 'От';
$_['entry_to']             = 'До';
$_['entry_customer_group'] = 'Клиентска група';
$_['entry_customer']       = 'Клиент';
$_['entry_affiliate']      = 'Афилиейт партньор';
$_['entry_product']        = 'Продукти';
$_['entry_subject']        = 'Заглавие';
$_['entry_message']        = 'Съобщение';

// Help
$_['help_customer']  = '(Автоматично попълване)';
$_['help_affiliate'] = '(Автоматично попълване)';
$_['help_product']   = 'Изпрати само на клиенти, които са направили поръчка на избраните продукти. (Автоматично попълване)';

// Error
$_['error_permission'] = 'Внимание: Нямате права да изпращате имейли!';
$_['error_subject']    = 'Заглавието е задължително!';
$_['error_message']    = 'Съобщението е задължително!';
$_['error_email']      = 'Няма получатели!';
