<?php
// Heading
$_['heading_title'] = 'Афилиейт';

// Text
$_['text_success']         = 'Готово: Променихте информацията за афилиейт партньорите!';
$_['text_list']            = 'Списък с афилиейт партньори';
$_['text_add']             = 'Нов афилиейт партньор';
$_['text_edit']            = 'Редактиране на афилиейт партньор';
$_['text_affiliate']       = 'Информация за афилиейт партньора';
$_['text_payment']         = 'Платежни данни';
$_['text_other']           = 'Други';
$_['text_balance']         = 'Баланс';
$_['text_cheque']          = 'Чек';
$_['text_paypal']          = 'PayPal';
$_['text_bank']            = 'Банков превод';
$_['text_history']         = 'История';
$_['text_history_add']     = 'Добавяне на запис';
$_['text_transaction']     = 'Транзакции';
$_['text_transaction_add'] = 'Добавяне на транзакция';
$_['text_report']          = 'Отчети';
$_['text_filter']          = 'Филтър';
$_['text_payment_cheque']  = 'Плащане с чек';
$_['text_payment_paypal']  = 'Плащане с PayPal';
$_['text_payment_bank']    = 'Плащане с банков превод';

// Column
$_['column_name']        = 'Име на клиента';
$_['column_tracking']    = 'Проследяване';
$_['column_commission']  = 'Комисионна';
$_['column_balance']     = 'Баланс';
$_['column_status']      = 'Статус';
$_['column_ip']          = 'IP адрес';
$_['column_account']     = 'Акаунти';
$_['column_store']       = 'Онлайн магазин';
$_['column_country']     = 'Държава';
$_['column_date_added']  = 'Дата на добавяне';
$_['column_comment']     = 'Коментар';
$_['column_description'] = 'Описание';
$_['column_amount']      = 'Сума';
$_['column_action']      = 'Действие';

// Entry
$_['entry_customer']            = 'Клиент';
$_['entry_company']             = 'Фирма';
$_['entry_tracking']            = 'Код за проследяване';
$_['entry_website']             = 'Уебсайт';
$_['entry_commission']          = 'Комисионна (%)';
$_['entry_tax']                 = 'Данъчен номер';
$_['entry_payment_method']      = 'Начин на плащане';
$_['entry_cheque']              = 'Лице за получаване на чек';
$_['entry_paypal']              = 'Имейл акаунт в PayPal';
$_['entry_bank_name']           = 'Име на банка';
$_['entry_bank_branch_number']  = 'ABA/BSB номер (Номер на клон)';
$_['entry_bank_swift_code']     = 'SWIFT код';
$_['entry_bank_account_name']   = 'Име на титуляр';
$_['entry_bank_account_number'] = 'Номер на банкова сметка (IBAN)';
$_['entry_comment']             = 'Коментар';
$_['entry_description']         = 'Описание';
$_['entry_amount']              = 'Сума';
$_['entry_date_from']           = 'От дата';
$_['entry_date_to']             = 'До дата';
$_['entry_status']              = 'Статус';
$_['entry_limit']               = 'Ограничение';

// Help
$_['help_tracking']   = 'Кодът за проследяване, който ще се използва за проследяване на препращанията.';
$_['help_commission'] = 'Процентът, който партньорът получава от всяка поръчка.';

// Error
$_['error_warning']             = 'Внимание: Моля, проверете внимателно формата за грешки!';
$_['error_permission']          = 'Внимание: Нямате права за промяна на информацията за афилиейт партньорите!';
$_['error_customer']            = 'Внимание: Полето клиент е задължително!';
$_['error_already']             = 'Внимание: Клиентът вече е регистриран като партньор!';
$_['error_tracking']            = 'Внимание: Кода за проследяване е задължителен!';
$_['error_exists']              = 'Кодът за проследяване се използва от друг партньор!';
$_['error_payment_method']      = 'Внимание: Начина на плащане е задължителен!';
$_['error_cheque']              = 'Внимание: Лицето за получаване на чек е задължително!';
$_['error_paypal']              = 'Внимание: Имейл адресът в PayPal изглежда невалиден!';
$_['error_bank_account_name']   = 'Внимание: Името на титуляра е задължително!';
$_['error_bank_account_number'] = 'Внимание: Номера на банкова сметка е задължителен!';
$_['error_custom_field']        = '%s е задължително поле!';