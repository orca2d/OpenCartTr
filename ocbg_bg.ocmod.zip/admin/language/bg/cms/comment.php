<?php
// Heading
$_['heading_title'] = 'Коментари към статия';

// Text
$_['text_success'] = 'Готово: Променихте коментарите към статиите!';
$_['text_next']    = 'Готово: Променихте оценката на %s коментара от %s на %s!';
$_['text_list']    = 'Списък с коментари към статии';
$_['text_filter']  = 'Филтър';
$_['text_by']      = 'по';
$_['text_info']    = 'Информация за коментара';
$_['text_rating']  = 'Оценка:';

// Column
$_['column_comment'] = 'Коментар';
$_['column_action']  = 'Действие';

// Entry
$_['entry_keyword']   = 'Ключови думи';
$_['entry_article']   = 'Статии';
$_['entry_customer']  = 'Клиент';
$_['entry_status']    = 'Статус';
$_['entry_date_from'] = 'От дата';
$_['entry_date_to']   = 'До дата';

// Button
$_['button_spam']   = 'СПАМ';
$_['button_rating'] = 'Изчисли оценка';

// Error
$_['error_permission'] = 'Внимание: Нямате права да променяте коментарите на статията!';
