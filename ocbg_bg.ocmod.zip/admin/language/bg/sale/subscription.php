<?php
// Heading
$_['heading_title'] = 'Абонаментни планове';

// Text
$_['text_success']               = 'Готово: Променихте абонаментите планове!';
$_['text_list']                  = 'Списък с абонаменти планове';
$_['text_add']                   = 'Нов абонаментен план';
$_['text_edit']                  = 'Абонаментен план (#%s)';
$_['text_filter']                = 'Филтър';
$_['text_date_added']            = 'Дата на добавяне';
$_['text_order_id']              = 'Номер';
$_['text_order']                 = 'Поръчка';
$_['text_product_add']           = 'Добави продукт';
$_['text_model']                 = 'Модел';
$_['text_subscription']          = 'Абонаментен план';
$_['text_date_next']             = 'Следваща дата';
$_['text_remaining']             = 'Оставащ';
$_['text_subscription_trial']    = '%s на всеки %d %s(а) за %d плащане(я) и след това ';
$_['text_subscription_duration'] = '%s на всеки %d %s(а) за %d плащане(я)';
$_['text_subscription_cancel']   = '%s на всеки %d %s(а) докато не бъде отказан';
$_['text_cancel']                = 'Докато не бъде отказан';
$_['text_day']                   = 'Ден';
$_['text_week']                  = 'Седмица';
$_['text_semi_month']            = 'Половин месец';
$_['text_month']                 = 'Месец';
$_['text_year']                  = 'Година';
$_['text_payment_method']        = 'Начин на плащане';
$_['text_payment']               = 'Моля, изберете предпочитания метод на плащане за този абонамент.';
$_['text_shipping_method']       = 'Начин на доставка';
$_['text_shipping']              = 'Моля, изберете предпочитания метод на доставка за този абонамент.';
$_['text_history']               = 'История';
$_['text_history_add']           = 'Добави';
$_['text_log']                   = 'Логове';

// Column
$_['column_subscription_id'] = 'Номер на абонаметния план';
$_['column_order_id']        = 'Номер';
$_['column_customer']        = 'Клиент';
$_['column_comment']         = 'Коментар';
$_['column_notify']          = 'Клиента е уведомен';
$_['column_status']          = 'Статус';
$_['column_date_added']      = 'Дата на добавяне';
$_['column_product']         = 'Продукт';
$_['column_model']           = 'Модел';
$_['column_quantity']        = 'Количество';
$_['column_trial_price']     = 'Цена на пробния период';
$_['column_price']           = 'Цена';
$_['column_amount']          = 'Сума';
$_['column_code']            = 'Код';
$_['column_description']     = 'Описание';
$_['column_action']          = 'Действие';

// Entry
$_['entry_subscription_id']     = 'Номер на абонаментния план';
$_['entry_order_id']            = 'Номер';
$_['entry_customer']            = 'Клиент';
$_['entry_store']               = 'Магазин';
$_['entry_language']            = 'Език';
$_['entry_currency']            = 'Валута';
$_['entry_subscription_plan']   = 'Абонаментен план';
$_['entry_date_next']           = 'Следваща дата';
$_['entry_comment']             = 'Коментар';
$_['entry_notify']              = 'Уведоми клиента';
$_['entry_date_from']           = 'От дата';
$_['entry_date_to']             = 'До дата';
$_['entry_subscription_status'] = 'Статус на абонаментния план';
$_['entry_product']             = 'Избери продукт';
$_['entry_option']              = 'Избери вариант(и)';
$_['entry_quantity']            = 'Количество';
$_['entry_payment_address']     = 'Адрес за плащане';
$_['entry_shipping_address']    = 'Адрес за доставка';

// Tab
$_['tab_order'] = 'Поръчки';

// Error
$_['error_permission']          = 'Внимание: Нямате право да променяте абонаментните планове!';
$_['error_subscription_status'] = 'Внимание: Трябва да се избере статус на абонаментния план!';
$_['error_payment_method']      = 'Внимание: Начинът на плащане не съществува!';