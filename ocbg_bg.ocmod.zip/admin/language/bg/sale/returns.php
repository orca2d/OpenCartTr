<?php
// Heading
$_['heading_title'] = 'Върнати продукти';

// Text
$_['text_success']     = 'Готово: Променихте върнатите продукти!';
$_['text_list']        = 'Списък с върнатите продукти';
$_['text_add']         = 'Нов върнат продукт';
$_['text_edit']        = 'Редактирай върнат продукт';
$_['text_order_id']    = 'Поръчка';
$_['text_filter']      = 'Филтър';
$_['text_customer']    = 'Клиент';
$_['text_date_added']  = 'Дата';
$_['text_return']      = 'Върнат продукт';
$_['text_product']     = 'Иберете продукт за връщане';
$_['text_opened']      = 'Отворен';
$_['text_unopened']    = 'Неотворен';
$_['text_history']     = 'История';
$_['text_history_add'] = 'Добави';

// Column
$_['column_return_id']  = 'Заявка за връщане номер';
$_['column_order_id']   = 'Номер';
$_['column_customer']   = 'Клиент';
$_['column_product']    = 'Продукт';
$_['column_model']      = 'Модел';
$_['column_quantity']   = 'Количество';
$_['column_status']     = 'Статус';
$_['column_date_added'] = 'Дата на добавяне';
$_['column_comment']    = 'Коментар';
$_['column_notify']     = 'Клиента е уведомен';
$_['column_action']     = 'Действие';

// Entry
$_['entry_customer']     = 'Клиент';
$_['entry_order_id']     = 'Номер';
$_['entry_date_ordered'] = 'Дата на поръчката';
$_['entry_firstname']    = 'Име';
$_['entry_lastname']     = 'Фамилия';
$_['entry_email']        = 'Имейл адрес';
$_['entry_telephone']    = 'Телефон';
$_['entry_product']      = 'Продукт';
$_['entry_model']        = 'Модел';
$_['entry_quantity']     = 'Количество';
$_['entry_opened']       = 'Отворен';
$_['entry_comment']      = 'Коментар';
$_['entry_reason']       = 'Причина за връщане';
$_['entry_action']       = 'Предприети действия';
$_['entry_status']       = 'Статус на връщане';
$_['entry_notify']       = 'Уведоми клиент';
$_['entry_return_id']    = 'Заявка за връщане номер';
$_['entry_date_from']    = 'От дата';
$_['entry_date_to']      = 'До дата';

// Help
$_['help_product'] = '(Автоматично попълване)';

// Error
$_['error_warning']    = 'Внимание: Моля, проверете внимателно формата за грешки!';
$_['error_permission'] = 'Внимание: Нямате право да променяте връщанията на продукти!';
$_['error_order']      = 'Поръчката не е намерена!';
$_['error_customer']   = 'Клиентът не е намерен!';
$_['error_firstname']  = 'Името трябва да бъде между 1 и 32 символа!';
$_['error_lastname']   = 'Фамилията трябва да бъде между 1 и 32 символа!';
$_['error_email']      = 'Имейл адресът изглежда невалиден!';
$_['error_telephone']  = 'Телефонът трябва да бъде между 3 и 32 символа!';
$_['error_product']    = 'Името на продукта трябва да бъде по-голямо от 1 и по-малко от 255 символа!';
$_['error_name']       = 'Името на продукта трябва да бъде между 1 и 255 символа!';
$_['error_model']      = 'Моделът на продукта трябва да бъде между 1 и 64 символа!';
$_['error_quantity']   = 'Количеството за връщане трябва да бъде поне 1!';
$_['error_reason']     = 'Моля, изберете причина за връщане!';
$_['error_action']     = 'Моля, изберете действие за връщане!';