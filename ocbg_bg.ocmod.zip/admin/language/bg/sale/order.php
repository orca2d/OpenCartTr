<?php
// Heading
$_['heading_title'] = 'Поръчки';

// Text
$_['text_success']               = 'Готово: Променихте поръчките!';
$_['text_list']                  = 'Списък с поръчки';
$_['text_add']                   = 'Добави Поръчка';
$_['text_edit']                  = 'Поръчка (#%s)';
$_['text_filter']                = 'Филтър';
$_['text_store']                 = 'Онлайн магазин';
$_['text_date_added']            = 'Дата на добавяне';
$_['text_customer']              = 'Клиент';
$_['text_product_add']           = 'Добави Продукт';
$_['text_model']                 = 'Модел';
$_['text_reward']                = 'Наградни точки';
$_['text_points']                = 'Точки';
$_['text_reward_add']            = 'Готово: Наградните точки са добавени!';
$_['text_reward_remove']         = 'Готово: Наградни точки са премахнати!';
$_['text_affiliate']             = 'Афилиейт партньор';
$_['text_commission']            = 'Комисионна';
$_['text_commission_add']        = 'Готово: Комисионната е добавена!';
$_['text_commission_remove']     = 'Готово: Комисионна е премахната!';
$_['text_upload']                = 'Файлът беше успешно качен!';
$_['text_subscription']          = 'Абонаментен план';
$_['text_subscription_trial']    = '%s на всеки %d %s(а) за %d плащане(я) и след това ';
$_['text_subscription_duration'] = '%s на всеки %d %s(а) за %d плащане(я)';
$_['text_subscription_cancel']   = '%s на всеки %d %s(а) докато не бъде отказан';
$_['text_day']                   = 'ден';
$_['text_week']                  = 'седмица';
$_['text_semi_month']            = 'половин месец';
$_['text_month']                 = 'месец';
$_['text_year']                  = 'година';
$_['text_more']                  = 'Виж повече...';
$_['text_less']                  = 'Събери...';
$_['text_payment_address']       = 'Адрес за плащане';
$_['text_payment_method']        = 'Начин на плащане';
$_['text_payment']               = 'Моля, изберете начин на плащане за тази поръчка.';
$_['text_shipping_address']      = 'Адрес за доставка';
$_['text_shipping_method']       = 'Начин на доставка';
$_['text_shipping']              = 'Моля, изберете начин на доставка за тази поръчка.';
$_['text_comment']               = 'Коментар';
$_['text_history']               = 'История';
$_['text_history_add']           = 'Добави в история на поръчката';
$_['text_browser']               = 'Браузър';
$_['text_ip']                    = 'IP адрес';
$_['text_forwarded_ip']          = 'Пренасочен IP адрес';
$_['text_user_agent']            = 'User Agent';
$_['text_accept_language']       = 'Достъпни езици';
$_['text_order_id']              = 'Номер';
$_['text_website']               = 'Уебсайт';
$_['text_invoice']               = 'Разписка';
$_['text_invoice_no']            = 'Номер на разписка';
$_['text_tbc']                   = 'TBC';
$_['text_store_address']         = 'Адрес на магазин';
$_['text_store_telephone']       = 'Телефон на магазин';
$_['text_store_email']           = 'Имейл на магазин';
$_['text_customer_email']        = 'Имейл на клиент';
$_['text_customer_telephone']    = 'Телефон на клиент';
$_['text_missing']               = 'Липсващи поръчки';
$_['text_default']               = 'По подразбиране';
$_['text_picklist']              = 'Списък за изпращане';

// Column
$_['column_order_id']      = 'Номер';
$_['column_customer']      = 'Клиент';
$_['column_store']         = 'Онлайн магазин';
$_['column_status']        = 'Статус';
$_['column_date_added']    = 'Дата на добавяне';
$_['column_date_modified'] = 'Дата на модификация';
$_['column_total']         = 'Общо';
$_['column_product']       = 'Продукт';
$_['column_model']         = 'Модел';
$_['column_quantity']      = 'Количество';
$_['column_price']         = 'Цена';
$_['column_comment']       = 'Коментар';
$_['column_notify']        = 'Клиентът е уведомен';
$_['column_location']      = 'Местоположение';
$_['column_reference']     = 'Препратка';
$_['column_weight']        = 'Тегло';
$_['column_action']        = 'Действие';

// Entry
$_['entry_store']           = 'Онлайн магазин';
$_['entry_customer']        = 'Клиент';
$_['entry_customer_group']  = 'Клиентска група';
$_['entry_firstname']       = 'Име';
$_['entry_lastname']        = 'Фамилия';
$_['entry_email']           = 'Имейл адрес';
$_['entry_telephone']       = 'Телефон';
$_['entry_address']         = 'Изберете адрес';
$_['entry_company']         = 'Фирма';
$_['entry_address_1']       = 'Адрес 1';
$_['entry_address_2']       = 'Адрес 2';
$_['entry_city']            = 'Град';
$_['entry_postcode']        = 'Пощенски код';
$_['entry_country']         = 'Държава';
$_['entry_zone']            = 'Област/Регион';
$_['entry_product']         = 'Изберете продукт';
$_['entry_option']          = 'Изберете опции';
$_['entry_subscription']    = 'Изберете абонаментен план';
$_['entry_quantity']        = 'Количество';
$_['entry_order_status']    = 'Статус';
$_['entry_notify']          = 'Уведоми клиента';
$_['entry_shipping_method'] = 'Начин на доставка';
$_['entry_payment_method']  = 'Начин на плащане';
$_['entry_override']        = 'Пренебрегни';
$_['entry_comment']         = 'Коментар';
$_['entry_language']        = 'Език';
$_['entry_currency']        = 'Валута';
$_['entry_affiliate']       = 'Афилиейт партньор';
$_['entry_order_id']        = 'Номер';
$_['entry_total']           = 'Общо';
$_['entry_date_from']       = 'От дата';
$_['entry_date_to']         = 'До дата';

// Help
$_['help_override'] = 'Ако промяната на статуса на поръчката на клиента е блокирана поради инструмент за защита срещу измами, активирайте презаписване.';

// Error
$_['error_warning']        = 'Внимание: Моля, проверете внимателно формата за грешки!';
$_['error_permission']     = 'Внимание: Нямате право да променяте поръчките!';
$_['error_invoice_no']     = 'Внимание: Разписката вече е създадена!';
$_['error_order']          = 'Внимание: Поръчката не съществува!';
$_['error_affiliate']      = 'Внимание: Афилиейт партньорът не съществува!';
$_['error_reward_add']     = 'Внимание: Наградните точки за тази поръчка вече са добавени!';
$_['error_reward_guest']   = 'Внимание: Гостите не могат да използват бонус точки!';
$_['error_commission_add'] = 'Внимание: Партньорската комисионна за тази поръчка вече е добавена!';