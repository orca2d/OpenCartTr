<?php
// Heading
$_['heading_title'] = 'Отчети';

// Text
$_['text_success'] = 'Готово: Променихте отчетите!';
$_['text_type']    = 'Избери вид на отчета';
$_['text_filter']  = 'Филтър';
