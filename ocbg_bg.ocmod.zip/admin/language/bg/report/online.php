<?php
// Heading
$_['heading_title'] = 'Посетители в реално време';

// Text
$_['text_extension'] = 'Разширения';
$_['text_success']   = 'Готово: Променихте отчета за посетители в реално време!';
$_['text_list']      = 'Списък с посетители в реално време';
$_['text_filter']    = 'Филтър';
$_['text_guest']     = 'Гост';

// Column
$_['column_ip']         = 'IP адрес';
$_['column_customer']   = 'Клиент';
$_['column_url']        = 'Последно посетена страница';
$_['column_referer']    = 'Препоръчан от';
$_['column_date_added'] = 'Последен клик';
$_['column_action']     = 'Действие';

// Entry
$_['entry_ip']       = 'IP адрес';
$_['entry_customer'] = 'Клиент';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте отчетите за посетители в реално време!';
