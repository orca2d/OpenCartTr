<?php
// Heading
$_['heading_title'] = 'Статистики';

// Text
$_['text_success']          = 'Готово: Променихте статистиките!';
$_['text_list']             = 'Списък със статистики';
$_['text_order_sale']       = 'Продажби от поръчки';
$_['text_order_processing'] = 'Обработвани поръчки';
$_['text_order_complete']   = 'Завършени поръчки';
$_['text_order_other']      = 'Други поръчки';
$_['text_returns']          = 'Върнати продукти';
$_['text_customer']         = 'Клиенти в очакване на одобрение';
$_['text_affiliate']        = 'Партньори в очакване на одобрение';
$_['text_product']          = 'Изчерпани продукти';
$_['text_review']           = 'Отзиви за преглед';

// Column
$_['column_name']   = 'Име на статистиката';
$_['column_value']  = 'Стойност';
$_['column_action'] = 'Действие';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте статистиките!';
