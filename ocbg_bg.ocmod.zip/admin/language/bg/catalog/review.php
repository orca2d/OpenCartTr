<?php
// Heading
$_['heading_title'] = 'Отзиви';

// Text
$_['text_success'] = 'Готово: Променихте отзивите!';
$_['text_next']    = 'Готово: Променихте %s на %s от %s отзивите за продукти!';
$_['text_list']    = 'Списък с отзиви';
$_['text_add']     = 'Нов отзив';
$_['text_edit']    = 'Редактирай отзив';
$_['text_filter']  = 'Филтър';

// Column
$_['column_product']    = 'Продукт';
$_['column_author']     = 'Автор';
$_['column_rating']     = 'Оценка';
$_['column_status']     = 'Статус';
$_['column_date_added'] = 'Дата на добавяне';
$_['column_action']     = 'Действие';

// Entry
$_['entry_product']    = 'Продукт';
$_['entry_author']     = 'Автор';
$_['entry_rating']     = 'Оценка';
$_['entry_status']     = 'Статус';
$_['entry_text']       = 'Текст';
$_['entry_date_added'] = 'Дата на добавяне';
$_['entry_date_from']  = 'От дата';
$_['entry_date_to']    = 'До дата';

// Help
$_['help_product'] = '(Автоматично попълване)';

// Button
$_['button_rating'] = 'Синхронизирай отзивите за продукти';

// Error
$_['error_warning']    = 'Внимание: Моля, проверете внимателно формата за грешки!';
$_['error_permission'] = 'Внимание: Нямате права да променяте  отзиви!';
$_['error_product']    = 'Необходимо е да изберете продукт!';
$_['error_author']     = 'Името на автора трябва да бъде между 3 и 64 символа!';
$_['error_text']       = 'Текстът на отзива трябва да бъде поне 1 символ!';
$_['error_rating']     = 'Необходимо е да оцените продукта!';
