<?php
// Heading
$_['heading_title'] = 'Филтри';

// Text
$_['text_success'] = 'Готово: Успешно обновихте филтрите!';
$_['text_list']    = 'Списък с филтри';
$_['text_add']     = 'Добави филтър';
$_['text_edit']    = 'Редактирай филтър';

// Column
$_['column_name']         = 'Име на филтър';
$_['column_filter_group'] = 'Група филтъри';
$_['column_sort_order']   = 'Подреждане';
$_['column_action']       = 'Действие';

// Entry
$_['entry_name']         = 'Име на филтър';
$_['entry_filter_group'] = 'Група филтъри';
$_['entry_sort_order']   = 'Подреждане';

// Error
$_['error_warning']      = 'Внимание: Моля, проверете внимателно формата за грешки!';
$_['error_permission']   = 'Внимание: Нямате права да променяте филтрите!';
$_['error_name']         = 'Името на филтър трябва да бъде между 1 и 64 символа!';
$_['error_filter_group'] = 'Необходима е група за филтриране!';
