<?php
// Heading
$_['heading_title'] = 'Известия';

// Text
$_['text_success'] = 'Готово: Успешно променихте известията!';
$_['text_list']    = 'Списък с известия';

// Column
$_['column_message'] = 'Съобщение';
$_['column_action']  = 'Действие';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте известията!';
