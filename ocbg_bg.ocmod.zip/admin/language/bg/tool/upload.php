<?php
// Heading
$_['heading_title'] = 'Качвания';

// Text
$_['text_success'] = 'Готово: Успешно променихте настройките за качвания!';
$_['text_list']    = 'Списък с качвания';
$_['text_filter']  = 'Филтър';

// Column
$_['column_name']       = 'Име при качване';
$_['column_code']       = 'Код';
$_['column_date_added'] = 'Дата на добавяне';
$_['column_action']     = 'Действие';

// Entry
$_['entry_name']      = 'Име при качване';
$_['entry_filename']  = 'Име на файл';
$_['entry_date_from'] = 'От дата';
$_['entry_date_to']   = 'До дата';

// Error
$_['error_permission']   = 'Внимание: Нямате право да променяте настройките за качвания!';
$_['error_not_found']    = 'Грешка: Не можа да намерим файла %s!';
$_['error_headers_sent'] = 'Грешка: Заглавията вече са изпратени!';
$_['error_upload']       = 'Файлът не може да бъде качен!';
$_['error_filename']     = 'Името на файла трябва да бъде между 3 и 128 символа!';
$_['error_file_type']    = 'Невалиден тип на файла!';