<?php
// Heading
$_['heading_title'] = 'Одобрения от клиенти';

// Text
$_['text_success']   = 'Готово: Променихте одобренията на клиентите!';
$_['text_list']      = 'Списък с одобрени клиенти';
$_['text_default']   = 'По подразбиране';
$_['text_customer']  = 'Клиент';
$_['text_affiliate'] = 'Афилиейт';
$_['text_filter']    = 'Филтър';
$_['text_approve']   = 'Одобри';
$_['text_deny']      = 'Откажи';

// Column
$_['column_customer']       = 'Клиент';
$_['column_email']          = 'Имейл адрес';
$_['column_customer_group'] = 'Клиентска група';
$_['column_type']           = 'Тип';
$_['column_date_added']     = 'Дата на добавяне';
$_['column_action']         = 'Действие';

// Entry
$_['entry_customer']       = 'Клиент';
$_['entry_email']          = 'Имейл адрес';
$_['entry_customer_group'] = 'Клиентска група';
$_['entry_type']           = 'Тип';
$_['entry_date_from']      = 'От дата';
$_['entry_date_to']        = 'До дата';

// Error
$_['error_permission'] = 'Внимание: Нямате права да променяте одобренията на клиенти!';
