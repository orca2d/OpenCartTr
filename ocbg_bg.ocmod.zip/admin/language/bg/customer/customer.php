<?php
// Heading
$_['heading_title'] = 'Клиенти';

// Text
$_['text_success']         = 'Готово: Променихте информацията за клиентите!';
$_['text_list']            = 'Списък с клиенти';
$_['text_add']             = 'Нов клиент';
$_['text_edit']            = 'Редактирай клиент';
$_['text_default']         = 'По подразбиране';
$_['text_store']           = 'Онлайн магазин';
$_['text_customer']        = 'Информация за клиента';
$_['text_password']        = 'Парола';
$_['text_other']           = 'Други';
$_['text_balance']         = 'Баланс';
$_['text_address']         = 'Адреси';
$_['text_address_add']     = 'Добави адрес';
$_['text_address_edit']    = 'Редактирай адрес';
$_['text_payment_method']  = 'Методи на плащане';
$_['text_history']         = 'История';
$_['text_history_add']     = 'Добави';
$_['text_transaction']     = 'Транзакции';
$_['text_transaction_add'] = 'Добави транзакция';
$_['text_reward']          = 'Бонус точки';
$_['text_reward_add']      = 'Добави бонус точки';
$_['text_ip']              = 'История на IP адреси';
$_['text_authorize']       = 'История на авторизации';
$_['text_option']          = 'Варианти';
$_['text_login']           = 'Влез като клиент';
$_['text_unlock']          = 'Отключи акаунт';
$_['text_filter']          = 'Филтър';

// Column
$_['column_name']           = 'Име на клиента';
$_['column_email']          = 'Имейл адрес';
$_['column_customer_group'] = 'Клиентска група';
$_['column_status']         = 'Статус';
$_['column_date_added']     = 'Дата на добавяне';
$_['column_comment']        = 'Коментар';
$_['column_description']    = 'Описание';
$_['column_amount']         = 'Сума';
$_['column_points']         = 'Точки';
$_['column_ip']             = 'IP адрес';
$_['column_account']        = 'Профил';
$_['column_store']          = 'Онлайн магазин';
$_['column_country']        = 'Държава';
$_['column_payment_method'] = 'Начин на плащане';
$_['column_image']          = 'Изображение';
$_['column_type']           = 'Тип';
$_['column_date_expire']    = 'Дата на изтичане';
$_['column_user_agent']     = 'User Agent';
$_['column_address']        = 'Адрес';
$_['column_action']         = 'Действие';

// Entry
$_['entry_store']          = 'Онлайн агазин';
$_['entry_language']        = 'Език';
$_['entry_customer_group'] = 'Клиентска група';
$_['entry_firstname']      = 'Име';
$_['entry_lastname']       = 'Фамилия';
$_['entry_email']          = 'Имейл адрес';
$_['entry_telephone']      = 'Телефон';
$_['entry_newsletter']     = 'Бюлетин';
$_['entry_status']         = 'Статус';
$_['entry_safe']           = 'Безопасен';
$_['entry_commenter']      = 'Коментиращ';
$_['entry_password']       = 'Парола';
$_['entry_confirm']        = 'Повтори паролата';
$_['entry_company']        = 'Фирма';
$_['entry_address_1']      = 'Адрес 1';
$_['entry_address_2']      = 'Адрес 2';
$_['entry_city']           = 'Град';
$_['entry_postcode']       = 'Пощенски код';
$_['entry_country']        = 'Държава';
$_['entry_zone']           = 'Област/Регион';
$_['entry_default']        = 'По подразбиране';
$_['entry_comment']        = 'Коментар';
$_['entry_description']    = 'Описание';
$_['entry_amount']         = 'Сума';
$_['entry_points']         = 'Точки';
$_['entry_name']           = 'Име на клиента';
$_['entry_ip']             = 'IP адрес';
$_['entry_date_from']      = 'Дата от';
$_['entry_date_to']        = 'Дата до';

// Tab
$_['tab_authorize'] = 'Упълномощаване';

// Button
$_['button_order'] = 'Поръчки';

// Help
$_['help_safe']      = 'Изберете "Да", за да предотвратите този клиент да бъде засечен от системата за защита от измами.';
$_['help_commenter'] = 'Изберете "Да", за да позволите на клиента да не бъде засечен от системата за защита от спам.';
$_['help_points']    = 'Използвайте минус, за да премахнете точки.';

// Error
$_['error_warning']      = 'Внимание: Моля, проверете внимателно формата за грешки!';
$_['error_permission']   = 'Внимание: Нямате права за промяна на информацията за клиентите!';
$_['error_customer']     = 'Внимание: Клиентът не съществува!';
$_['error_exists']       = 'Внимание: Имейл адресът вече е регистриран!';
$_['error_address']      = 'Внимание: Адресът не съществува!';
$_['error_firstname']    = 'Името трябва да бъде между 1 и 32 символа!';
$_['error_lastname']     = 'Фамилията трябва да бъде между 1 и 32 символа!';
$_['error_email']        = 'Имейл адресът изглежда невалиден!';
$_['error_telephone']    = 'Телефонният номер трябва да бъде между 3 и 32 символа!';
$_['error_password']     = 'Паролата трябва да бъде между 6 и 20 символа!';
$_['error_confirm']      = 'Паролата и потвърждението на паролата не съвпадат!';
$_['error_address_1']    = 'Адрес 1 трябва да бъде между 3 и 128 символа!';
$_['error_city']         = 'Градът трябва да бъде между 2 и 128 символа!';
$_['error_postcode']     = 'Пощенският код трябва да бъде между 2 и 10 символа!';
$_['error_country']      = 'Моля, изберете държава!';
$_['error_zone']         = 'Моля, изберете област/регион!';
$_['error_custom_field'] = '%s е задължително поле!';
$_['error_regex']        = '%s не е валидна стойност!';
