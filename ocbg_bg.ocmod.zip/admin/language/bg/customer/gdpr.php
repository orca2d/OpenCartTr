<?php
// Heading
$_['heading_title'] = 'GDPR одобрения';

// Text
$_['text_success']    = 'Готово: Променихте одобренията по GDPR!';
$_['text_list']       = 'Списък с одобрения по GDPR';
$_['text_info']       = 'Заявките за изтриване на профил по GDPR ще бъдат обработени след <strong>%s дни</strong>.';
$_['text_approve']    = 'Одобри';
$_['text_deny']       = 'Откажи';
$_['text_delete']     = 'Изтрий';
$_['text_unverified'] = 'Непотвърдено';
$_['text_pending']    = 'В очакване';
$_['text_processing'] = 'В процес на обработка';
$_['text_complete']   = 'Завършено';
$_['text_denied']     = 'Отказано';
$_['text_export']     = 'Експорт';
$_['text_remove']     = 'Премахни';
$_['text_filter']     = 'Филтър';

// Column
$_['column_email']      = 'Имейл адрес';
$_['column_request']    = 'Заявка';
$_['column_status']     = 'Статус';
$_['column_date_added'] = 'Дата на добавяне';
$_['column_action']     = 'Действие';

// Entry
$_['entry_email']     = 'Имейл адрес';
$_['entry_action']    = 'Действие';
$_['entry_status']    = 'Статус';
$_['entry_date_from'] = 'От дата';
$_['entry_date_to']   = 'До дата';

// Error
$_['error_permission'] = 'Внимание: Нямате права да променяте одобренията по GDPR!';
