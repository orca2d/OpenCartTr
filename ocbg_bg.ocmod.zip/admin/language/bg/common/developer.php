<?php
// Heading
$_['heading_title'] = 'За Разработчици';

// Text
$_['text_developer_success'] = 'Готово: Променихте настройките за разработчици!';
$_['text_cache_success']     = 'Готово: Изчистихте кеша!';
$_['text_theme_success']     = 'Готово: Изчистихте кеша на темата!';
$_['text_sass_success']      = 'Готово: Изчистихте кеша на SASS!';
$_['text_vendor_success']    = 'Готово: Изчистихте кеша на vendor!';
$_['text_theme']             = 'Тема';
$_['text_sass']              = 'SASS';
$_['text_cache']             = 'Кеш';
$_['text_vendor']            = 'Vendor';

// Column
$_['column_component'] = 'Компоненти';
$_['column_action']    = 'Действие';

// Entry
$_['entry_cache'] = 'Кеш';

// Buttons
$_['button_on']  = 'Вкл.';
$_['button_off'] = 'Изкл.';

// Error
$_['error_permission'] = 'Внимание: Нямате права да променяте настройките за разработчици!';
