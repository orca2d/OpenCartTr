<?php
// Heading
$_['heading_title'] = 'Важни известия за сигурност!';

// Text
$_['text_install']                    = 'Изтрийте инсталационната папка';
$_['text_install_description']        = 'Инсталационната папка трябва да бъде изтрита!';
$_['text_install_success']            = 'Готово: Инсталационната папка е изтрита!';
$_['text_storage']                    = 'Преместете на папката за storage';
$_['text_storage_description']        = 'Много е важно папката storage да бъде извън папката за достъп през уеб (например: public_html, www или htdocs).';
$_['text_storage_move']               = 'Преместване на %s в %s от %s файлове в storage';
$_['text_storage_success']            = 'Готово: Папката storage е преместена!';
$_['text_storage_delete']             = 'Изтриване на предишната папка storage';
$_['text_storage_delete_description'] = 'Предишната папка storage трябва да бъде изтрита!';
$_['text_storage_delete_success']     = 'Готово: Предишната папка storage е изтрита!';
$_['text_admin']                      = 'Преместване на папката аdmin';
$_['text_admin_description']          = 'Моля, въведете ново име за папката admin в полето по-долу.';
$_['text_admin_move']                 = 'Преместване на %s в %s от %s admin файла';
$_['text_admin_success']              = 'Готово: Папката admin е преместена!';
$_['text_admin_delete']               = 'Изтриване на предишната папка аdmin';
$_['text_admin_delete_description']   = 'Предишната папка "admin" трябва да бъде изтрита!';
$_['text_admin_delete_success']       = 'Готово: Предишната папка admin е изтрита!';
$_['text_path']                       = 'Път';

// Entry
$_['entry_path']         = 'Път';
$_['entry_path_current'] = 'Текущ път';
$_['entry_path_new']     = 'Нов път';
$_['entry_name']         = 'Име на папка';

// Buttons
$_['button_move'] = 'Премести';

// Help
$_['help_storage'] = 'Името на папката storage трябва да започва със storage. напр. `storage_`.';

// Error
$_['error_permission']    = 'Внимание: Нямате права за промяна на секцията за сигурност!';
$_['error_install']       = 'Внимание: Инсталационната папка не съществува!';
$_['error_storage']       = 'Внимание: Папката за storage не съществува!';
$_['error_storage_root']  = 'Внимание: Папката storageтрябва да бъде извън root папката на уебсайта!';
$_['error_storage_name']  = 'Внимание: Името на папката storage трябва да започва с `storage`! Например: `storage_`.';
$_['error_admin']         = 'Внимание: Папката admin не съществува!';
$_['error_admin_allowed'] = 'Внимание: Това име на папка admin не може да се използва!';
$_['error_admin_exists']  = 'Внимание: Папката admin вече съществува!';
$_['error_writable']      = 'Внимание: config.php и admin/config.php трябва да бъдат с права за запис!';
$_['error_remove']        = 'Внимание: Папката, която трябва да се премахне, не съществува!';
