<?php
// Heading
$_['heading_title'] = 'OpenCart България';

// Text
$_['text_notification']      = 'Известия';
$_['text_notification_all']  = 'Покажи всички';
$_['text_notification_none'] = 'Няма известия';
$_['text_profile']           = 'Вашият профил';
$_['text_store']             = 'Онлайн магазини';
$_['text_help']              = 'Помощ';
$_['text_homepage']          = 'Начална страница на OpenCart';
$_['text_support']           = 'Форум за поддръжка';
$_['text_documentation']     = 'Документация';
$_['text_logout']            = 'Изход';
