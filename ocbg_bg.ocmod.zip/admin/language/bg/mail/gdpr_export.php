<?php
// Text
$_['text_subject']    = '%s - Заявката за експорт на данни по GDPR Регламента е изпълнена!';
$_['text_request']    = 'Експортиране на лични данни';
$_['text_hello']      = 'Здравейте <strong>%s</strong>,';
$_['text_user']       = 'Потребител';
$_['text_gdpr']       = 'Вашата заявка за данни по GDPR Регламента е вече изпълнена. По-долу ще намерите вашите данни по GDPR.';
$_['text_account']    = 'Профил';
$_['text_customer']   = 'Лична информация';
$_['text_address']    = 'Адрес';
$_['text_addresses']  = 'Адреси';
$_['text_name']       = 'Име на клиента';
$_['text_recipient']  = 'Получател';
$_['text_email']      = 'Имейл адрес';
$_['text_telephone']  = 'Телефон';
$_['text_company']    = 'Фирма';
$_['text_address_1']  = 'Адрес 1';
$_['text_address_2']  = 'Адрес 2';
$_['text_postcode']   = 'Пощенски код';
$_['text_city']       = 'Град';
$_['text_country']    = 'Държава';
$_['text_zone']       = 'Област/Регион';
$_['text_history']    = 'История на влизанията';
$_['text_ip']         = 'IP адрес';
$_['text_date_added'] = 'Дата на създаване';
$_['text_thanks']     = 'Поздрави,';
