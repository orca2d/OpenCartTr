<?php
// Heading
$_['heading_title'] = 'Редактор на теми';

// Text
$_['text_success']   = 'Готово: Променихте темите!';
$_['text_add']       = 'Нова тема';
$_['text_edit']      = 'Редактирай тема';
$_['text_default']   = 'По подразбиране';
$_['text_extension'] = 'Разширения';
$_['text_code']      = 'Редактро на код';
$_['text_twig']      = 'Редакторът на теми използва език за шаблони Twig. Можете да прочетете за <a href="https://twig.symfony.com/doc/2.x/templates.html" target="_blank" class="alert-link">синтаксиса на Twig тук</a>.';

// Column
$_['column_store']      = 'Онлайн магазин';
$_['column_route']      = 'Път';
$_['column_status']     = 'Статус';
$_['column_date_added'] = 'Дата на добавяне';
$_['column_action']     = 'Действие';

// Entry
$_['entry_store']  = 'Онлайн магазин';
$_['entry_route']  = 'Избери шаблон';
$_['entry_code']   = 'Код';
$_['entry_status'] = 'Статус';

// Error
$_['error_permission'] = 'Внимание: Нямате права за промяна на редактора на теми!';
$_['error_file']       = 'Внимание: Файлът с шаблона не съществува!';