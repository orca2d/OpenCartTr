<?php
// Heading
$_['heading_title'] = 'Езиков редактор';

// Text
$_['text_success']  = 'Готово: Променихте езиковият редактор!';
$_['text_list']     = 'Списък с преводи';
$_['text_add']      = 'Нов превод';
$_['text_edit']     = 'Редактирай превод';
$_['text_default']  = 'По подразбиране';
$_['text_store']    = 'Онлайн магазин';
$_['text_language'] = 'Език';

// Column
$_['column_store']    = 'Онлайн магазин';
$_['column_language'] = 'Език';
$_['column_route']    = 'Път';
$_['column_key']      = 'Ключ';
$_['column_value']    = 'Стойност';
$_['column_action']   = 'Действие';

// Entry
$_['entry_store']    = 'Онлайн магазин';
$_['entry_language'] = 'Език';
$_['entry_route']    = 'Път';
$_['entry_key']      = 'Ключ';
$_['entry_default']  = 'По подразбиране';
$_['entry_value']    = 'Стойност';

// Error
$_['error_permission'] = 'Внимание: Нямате права за промяна на редактора на преводи!';
$_['error_key']        = 'Ключът трябва да е между 3 и 64 символа!';