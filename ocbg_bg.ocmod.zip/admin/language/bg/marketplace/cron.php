<?php
// Heading
$_['heading_title'] = 'CRON задачи';

// Text
$_['text_success']     = 'Готово: Променихте CRON задачите!';
$_['text_instruction'] = 'Инструкции за CRON задачи';
$_['text_list']        = 'Списък с CRON задачи';
$_['text_cron_1']      = 'CRON задачите са планирани задачи, които се изпълняват периодично. За да настроите вашите сървъри да използват CRON задачи, можете да прочетете <a href="http://docs.opencart.com/extension/cron/" target="_blank" class="alert-link">документацията на OpenCart</a>.';
$_['text_cron_2']      = 'Трябва да настроите вашата CRON задача да се изпълнява на всеки час.';
$_['text_info']        = 'Информация за CRON задача';
$_['text_hour']        = 'Час';
$_['text_day']         = 'Ден';
$_['text_month']       = 'Месец';

// Column
$_['column_code']          = 'CRON код';
$_['column_cycle']         = 'Цикъл';
$_['column_date_added']    = 'Дата на добавяне';
$_['column_date_modified'] = 'Дата на промяна';
$_['column_action']        = 'Действие';

// Entry
$_['entry_cron']        = 'CRON URL адрес';
$_['entry_description'] = 'Описание';

// Error
$_['error_permission'] = 'Внимание: Нямате право да модифицирате CRON задачите!';
