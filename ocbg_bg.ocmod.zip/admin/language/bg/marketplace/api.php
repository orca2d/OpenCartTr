<?php
// Heading
$_['heading_title'] = 'OpenCart маркетплейс API';

// Text
$_['text_success'] = 'Готово: Променихте API информацията!';
$_['text_signup']  = 'Моля, въведете вашата OpenCart API информация, която може да намерите <a href="https://www.opencart.com/index.php?route=account/store" target="_blank" class="alert-link">тук</a>.';

// Entry
$_['entry_username'] = 'Потребителско име';
$_['entry_secret']   = 'Таен код';

// Error
$_['error_permission'] = 'Внимание: Нямате право да модифицирате API-то на маркетплейса!';
$_['error_username']   = 'Потребителското име е задължително!';
$_['error_secret']     = 'Тайният код е задължителен!';
