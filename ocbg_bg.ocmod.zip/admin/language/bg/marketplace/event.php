<?php
// Heading
$_['heading_title'] = 'Събития (Events)';

// Text
$_['text_success'] = 'Готово: Променихте събитията (Events)!';
$_['text_list']    = 'Списък със събития (Events)';
$_['text_event']   = 'Събитията (Events) се използват от разширенията, за да се пренапише стандартната функционалност на вашия онлайн магазин. Ако имате проблеми, тук можете да деактивирате или активирате събитията (Events).';
$_['text_info']    = 'Информация за събитието (Events)';

// Column
$_['column_code']       = 'Код на събитие (Events)';
$_['column_sort_order'] = 'Подреждане';
$_['column_action']     = 'Действие';

// Entry
$_['entry_description'] = 'Описание';
$_['entry_trigger']     = 'Тригер (Trigger)';
$_['entry_action']      = 'Действие';

// Error
$_['error_permission'] = 'Внимание: Нямате право да модифицирате събитията (Еvents)!';
