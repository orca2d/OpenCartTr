<?php
// Text
$_['text_recommended'] = 'Препоръчано';
$_['text_install']     = 'Инсталирай';
$_['text_uninstall']   = 'Деинсталирай';
$_['text_delete']      = 'Изтрий';
