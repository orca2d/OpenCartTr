<?php
// Heading
$_['heading_title'] = 'Маркетплейс с разшриения';

// Text
$_['text_success']       = 'Готово: Променихте разширенията!';
$_['text_list']          = 'Списък с разширения';
$_['text_filter']        = 'Филтър';
$_['text_search']        = 'Търсене на разширения и теми';
$_['text_category']      = 'Категории';
$_['text_all']           = 'Всички';
$_['text_theme']         = 'Теми';
$_['text_marketplace']   = 'Маркетплейси';
$_['text_language']      = 'Езици';
$_['text_payment']       = 'Плащания';
$_['text_shipping']      = 'Доставка';
$_['text_module']        = 'Модули';
$_['text_total']         = 'Общи суми за поръчки';
$_['text_feed']          = 'Потоци';
$_['text_report']        = 'Отчети';
$_['text_other']         = 'Други';
$_['text_free']          = 'Безплатно';
$_['text_paid']          = 'Платено';
$_['text_purchased']     = 'Закупено';
$_['text_recommended']   = 'Препоръчани';
$_['text_date_modified'] = 'Дата на модификация';
$_['text_date_added']    = 'Дата на добавяне';
$_['text_rating']        = 'Оценка';
$_['text_reviews']       = 'прегледи';
$_['text_compatibility'] = 'Съвместимост';
$_['text_downloaded']    = 'Изтеглени';
$_['text_member_since']  = 'Член от:';
$_['text_price']         = 'Цена';
$_['text_featured']      = 'Препоръчани';
$_['text_partner']       = 'Разработено от OpenCart партньор';
$_['text_support']       = '12 месеца безплатна поддръжка';
$_['text_documentation'] = 'Документацията включена';
$_['text_sales']         = 'Продажби';
$_['text_comment']       = 'Коментари';
$_['text_download']      = 'Изтегляне';
$_['text_install']       = 'Инсталиране';
$_['text_comment_add']   = 'Оставете ваш коментар';
$_['text_write']         = 'Напишете вашия коментар тук.';
$_['text_purchase']      = 'Моля, потвърдете кой сте!';
$_['text_pin']           = 'Моля, въведете вашия 4-цифрен ПИН. Този ПИН е за защита на вашия акаунт.';
$_['text_secure']        = 'Не давайте ПИН кода на никого (включително разработчици). Ако имате нужда от помощ, моля изпратете имейл на продавача на разширението относно конкретния пакет с разширения.';
$_['text_name']          = 'Име на изтеглянето';
$_['text_available']     = 'Налични инсталации';
$_['text_action']        = 'Действие';
$_['text_install']       = 'Инсталирай';
$_['text_uninstall']     = 'Деинсталирай';
$_['text_delete']        = 'Изтрий';
$_['text_more']          = 'виж още отговори...';
$_['text_refresh']       = 'обнови';

// Entry
$_['entry_pin']          = 'ПИН';

// Tabs
$_['tab_description']   = 'Описание';
$_['tab_documentation'] = 'Докуметация';
$_['tab_download']      = 'Изтегляния';
$_['tab_comment']       = 'Коментар';

// Buttons
$_['button_api']        = 'Маркетплейс API';
$_['button_purchase']   = 'Купи';
$_['button_view_all']   = 'Виж всички разширения';
$_['button_support']    = 'Искам поддръжка';
$_['button_comment']    = 'Коментар';
$_['button_reply']      = 'Отговор';
$_['button_forgot_pin'] = 'Забравен ПИН?';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте разширенията!';
$_['error_api']        = 'Внимание: Трябва да въведете вашата информация за OpenCart API, като щракнете върху <i class="fa-solid fa-triangle-exclamation"></i>, преди да можете да изтегляте разширения или да извършвате покупки!';
$_['error_purchase']   = 'Разширението не можа да бъде закупено!';
$_['error_download']   = 'Разширението не можа да бъде изтеглено!';