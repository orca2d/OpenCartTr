<?php
// Heading
$_['heading_title'] = 'Стартиране';

// Text
$_['text_success'] = 'Готово: Променихте настройките за стартиране!';
$_['text_list']    = 'Списък';
$_['text_info']    = 'Информация за стартиране';

// Column
$_['column_code']       = 'Startup код';
$_['column_sort_order'] = 'Подреждане';
$_['column_action']     = 'Действие';

// Entry
$_['entry_description'] = 'Описание';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте настройките за стартиране!';
