<?php
// Heading
$_['heading_title'] = 'Табло';

// Text
$_['text_success'] = 'Готово: Променихте таблата!';
$_['text_list']    = 'Списък с табла';

// Column
$_['column_name']       = 'Име на таблото';
$_['column_width']      = 'Широчина';
$_['column_status']     = 'Статус';
$_['column_sort_order'] = 'Подреждане';
$_['column_action']     = 'Действие';

// Error
$_['error_permission'] = 'Внимание: Нямате права за промяна на таблата!';
$_['error_extension']  = 'Внимание: Разширението не съществува!';