<?php
// Heading
$_['heading_title'] = 'Платежни системи';

// Text
$_['text_success'] = 'Готово: Променихте платежните системи!';
$_['text_list']    = 'Списък с платежни системи';

// Column
$_['column_name']       = 'Начин на плащане';
$_['column_vendor']     = 'Vendor';
$_['column_status']     = 'Статус';
$_['column_sort_order'] = 'Подреждане';
$_['column_action']     = 'Действие';

// Error
$_['error_permission'] = 'Внимание: Нямате права за промяна на начините за плащане!';
$_['error_extension']  = 'Внимание: Разширението не съществува!';
