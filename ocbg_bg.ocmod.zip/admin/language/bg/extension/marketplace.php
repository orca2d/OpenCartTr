<?php
// Heading
$_['heading_title'] = 'Маркетплейс';

// Text
$_['text_success'] = 'Готово: Променихте маркетплейса!';
$_['text_list']    = 'Списък с разширения';

// Column
$_['column_name']   = 'Име на разшриение';
$_['column_status'] = 'Статус';
$_['column_action'] = 'Действие';

// Error
$_['error_permission'] = 'Внимание: Нямате права за промяна на маркетплейсите!';
$_['error_extension']  = 'Внимание: Разширението не съществува!';
