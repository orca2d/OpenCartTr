<?php
// Heading Title
$_['heading_title'] = 'Промоции';
