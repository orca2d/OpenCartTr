<?php
// Text
$_['text_coupon']  = 'Купон код';

// Entry
$_['entry_coupon'] = 'Купон код';
