<?php
// Heading
$_['heading_title'] = 'Fixer - Конвертиране на валути';

// Text
$_['text_extension'] = 'Разширения';
$_['text_success']   = 'Готово: Променихте Fixer - Конвертиране на валути!';
$_['text_edit']      = 'Редактиране на Fixer';
$_['text_signup']    = 'Fixer.io услуга за обменни курсове на валути <a href="https://fixer.io/" target="_blank" class="alert-link">Регистрирайте се тук</a>.';

// Entry
$_['entry_api']    = 'API ключ за достъп';
$_['entry_status'] = 'Статус';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте Fixer - Конвертиране на валути!';
$_['error_api']        = 'API ключа за достъп е задължителен!';
