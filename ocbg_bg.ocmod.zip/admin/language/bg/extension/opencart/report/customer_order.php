<?php
// Heading
$_['heading_title']         = 'Отчет за поръчки';

// Text
$_['text_extension']        = 'Разширения';
$_['text_edit']             = 'Редактиране на отчета за поръчки';
$_['text_success']          = 'Готово: Променихте отчета за поръчки!';
$_['text_filter']           = 'Филтър';
$_['text_all_status']       = 'Всички статуси';

// Column
$_['column_customer']       = 'Име на клиент';
$_['column_email']          = 'Имейл адрес';
$_['column_customer_group'] = 'Клиентска група';
$_['column_status']         = 'Статус';
$_['column_orders']         = 'Брой поръчки';
$_['column_products']       = 'Брой продукти';
$_['column_total']          = 'Общо';
$_['column_action']         = 'Действие';

// Entry
$_['entry_date_start']      = 'Начална дата';
$_['entry_date_end']        = 'Крайна дата';
$_['entry_customer']        = 'Клиент';
$_['entry_order_status']    = 'Статус на поръчка';
$_['entry_status']          = 'Статус';
$_['entry_sort_order']      = 'Подреждане';

// Error
$_['error_permission']      = 'Внимание: Нямате право да променяте отчета за поръчки!';
