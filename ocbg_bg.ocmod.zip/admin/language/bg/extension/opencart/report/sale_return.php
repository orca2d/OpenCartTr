<?php
// Heading
$_['heading_title']       = 'Отчет за върнати продукти';

// Text
$_['text_extension']      = 'Разширения';
$_['text_edit']           = 'Редактиране на отчет за върнати продукти';
$_['text_success']        = 'Готово: Променихте отчета за върнати продукти!';
$_['text_filter']         = 'Филтър';
$_['text_year']           = 'Години';
$_['text_month']          = 'Месеци';
$_['text_week']           = 'Седмици';
$_['text_day']            = 'Дни';
$_['text_all_status']     = 'Всички сатуси';

// Column
$_['column_date_start']   = 'Начална дата';
$_['column_date_end']     = 'Крайна дата';
$_['column_returns']      = 'Брой върнати продукта';

// Entry
$_['entry_date_start']    = 'Начална дата';
$_['entry_date_end']      = 'Крайна дата';
$_['entry_group']         = 'Групирай по';
$_['entry_return_status'] = 'Статус на върнати продукти';
$_['entry_status']        = 'Статус';
$_['entry_sort_order']    = 'Подреждане';

// Error
$_['error_permission']    = 'Внимание: Нямате право да променяте отчета за върнати продукти!';
