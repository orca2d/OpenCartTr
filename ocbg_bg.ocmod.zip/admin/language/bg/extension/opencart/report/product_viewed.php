<?php
// Heading
$_['heading_title']    = 'Отчет за разглеждани продукти';

// Text
$_['text_extension']   = 'Разширения';
$_['text_edit']        = 'Редактиране на отчет за разглеждани продукти';
$_['text_success']     = 'Готово: Променихте отчета за разглеждани продукти!';
$_['text_progress']    = 'Остават %s от %s!';

// Column
$_['column_name']      = 'Име на продукт';
$_['column_model']     = 'Модел';
$_['column_viewed']    = 'Разглеждания';
$_['column_percent']   = 'Процент';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Подреждане';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте отчета за разглеждани продукти!';
