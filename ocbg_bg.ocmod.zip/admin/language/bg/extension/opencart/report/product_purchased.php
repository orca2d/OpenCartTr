<?php
// Heading
$_['heading_title']      = 'Отчет за продадени продукта';

// Text
$_['text_extension']     = 'Разширения';
$_['text_edit']          = 'Редактиране на отчет за продадени продукта';
$_['text_success']       = 'Готово: Променихте отчета за продадени продукта!';
$_['text_filter']        = 'Филтър';
$_['text_all_status']    = 'Всички сатуси';

// Column
$_['column_date_start']  = 'Начална дата';
$_['column_date_end']    = 'Крайна дата';
$_['column_name']        = 'Име на продукт';
$_['column_model']       = 'Модел';
$_['column_quantity']    = 'Количество';
$_['column_total']       = 'Общо';

// Entry
$_['entry_date_start']   = 'Начална дата';
$_['entry_date_end']     = 'Крайна дата';
$_['entry_order_status'] = 'Статус на поръчка';
$_['entry_status']       = 'Статус';
$_['entry_sort_order']   = 'Подреждане';

// Error
$_['error_permission']   = 'Внимание: Нямате право да променяте отчета за продадени продукта!';
