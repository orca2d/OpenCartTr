<?php
// Heading
$_['heading_title']      = 'Маркетингови отчети';

// Text
$_['text_extension']     = 'Разширения';
$_['text_edit']          = 'Редактиране на маркетингови отчети';
$_['text_success']       = 'Готово: Променихте маркетинговите отчети!';
$_['text_filter']        = 'Филтър';
$_['text_all_status']    = 'Всички сатуси';

// Column
$_['column_campaign']    = 'Име на кампанията';
$_['column_code']        = 'Код';
$_['column_clicks']      = 'Кликове';
$_['column_orders']      = 'Брой поръчки';
$_['column_total']       = 'Общо';

// Entry
$_['entry_date_start']   = 'Начална дата';
$_['entry_date_end']     = 'Крайна дата';
$_['entry_order_status'] = 'Статус на поръчка';
$_['entry_status']       = 'Статус';
$_['entry_sort_order']   = 'Подреждане';

// Error
$_['error_permission']   = 'Внимание: Нямате право да променяте маркетинговите отчети!';
