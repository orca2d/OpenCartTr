<?php
// Heading
$_['heading_title']     = 'Отчет за клиенти';

// Text
$_['text_extension']    = 'Разширения';
$_['text_edit']         = 'Редактиране на отчет за клиенти';
$_['text_success']      = 'Готово: Променихте отчета за клиенти!';
$_['text_filter']       = 'Филтър';
$_['text_year']         = 'Година';
$_['text_month']        = 'Месеци';
$_['text_week']         = 'Седмици';
$_['text_day']          = 'Дни';
$_['text_all_status']   = 'Всички статуси';

// Column
$_['column_date_start'] = 'Начална дата';
$_['column_date_end']   = 'Крайна дата';
$_['column_total']      = 'Общо клиенти';

// Entry
$_['entry_date_start']  = 'Начална дата';
$_['entry_date_end']    = 'Крайна дата';
$_['entry_group']       = 'Групиране по';
$_['entry_status']      = 'Статус';
$_['entry_sort_order']  = 'Подреждане';

// Error
$_['error_permission']  = 'Внимание: Нямате право да променяте отчета за клиенти!';
