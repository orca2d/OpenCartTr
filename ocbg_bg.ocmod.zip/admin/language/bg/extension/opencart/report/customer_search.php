<?php
// Heading
$_['heading_title']     = 'Отчет за клиентски търсения';

// Text
$_['text_extension']    = 'Разширения';
$_['text_edit']         = 'Редактиране на отчет за клиентски търсения';
$_['text_success']      = 'Готово: Променихте отчета за клиентски търсения!';
$_['text_filter']       = 'Филтър';
$_['text_guest']        = 'Гост';
$_['text_customer']     = '<a href="%s">%s</a>';

// Column
$_['column_keyword']    = 'Ключови думи';
$_['column_products']   = 'Намерени продукти';
$_['column_category']   = 'Категория';
$_['column_customer']   = 'Клиент';
$_['column_ip']         = 'IP';
$_['column_date_added'] = 'Дата на добавяне';

// Entry
$_['entry_date_start']  = 'Начална дата';
$_['entry_date_end']    = 'Крайна дата';
$_['entry_keyword']     = 'Keyword';
$_['entry_customer']    = 'Клиент';
$_['entry_ip']          = 'IP';
$_['entry_status']      = 'Статус';
$_['entry_sort_order']  = 'Подреждане';

// Error
$_['error_permission']  = 'Внимание: Нямате право да променяте отчета за клиентски търсения!';
