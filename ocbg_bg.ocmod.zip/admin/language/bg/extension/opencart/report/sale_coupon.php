<?php
// Heading
$_['heading_title']    = 'Отчет за кодове с отстъпка';

// Text
$_['text_extension']   = 'Разширения';
$_['text_edit']        = 'Редактиране на отчет за кодове с отстъпка';
$_['text_success']     = 'Готово: Променихте отчета за кодове с отстъпка!';
$_['text_filter']      = 'Филтър';

// Column
$_['column_name']      = 'Име на кода';
$_['column_code']      = 'Код';
$_['column_orders']    = 'Поръчки';
$_['column_total']     = 'Общо';
$_['column_action']    = 'Действие';

// Entry
$_['entry_date_start'] = 'Начална дата';
$_['entry_date_end']   = 'Крайна дата';
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Подреждане';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте отчета за кодове с отстъпка!';
