<?php
// Heading
$_['heading_title'] = 'Базова капча';

// Text
$_['text_extension'] = 'Разширения';
$_['text_success']   = 'Готово: Променихте базовата капча!';
$_['text_edit']      = 'Редактиране на Basic Captcha';

// Entry
$_['entry_status'] = 'Статус';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте базовата капча!';