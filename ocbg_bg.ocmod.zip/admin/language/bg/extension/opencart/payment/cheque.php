<?php
// Heading
$_['heading_title']      = 'Чек';

// Text
$_['text_extension']     = 'Разширения';
$_['text_success']       = 'Готово: Променихте модула за чек!';
$_['text_edit']          = 'Редактиране на модуал за чек';

// Entry
$_['entry_payable']      = 'Заплаща се на';
$_['entry_order_status'] = 'Статус на поръчка';
$_['entry_geo_zone']     = 'Гео зона';
$_['entry_status']       = 'Статус';
$_['entry_sort_order']   = 'Подреждане';

// Error
$_['error_permission']   = 'Внимание: Нямате право да променяте метода за плащане с чек!';
$_['error_payable']      = 'Необходимо е да се попълни полето "Платец"!';
