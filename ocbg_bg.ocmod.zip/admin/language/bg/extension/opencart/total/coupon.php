<?php
// Heading
$_['heading_title']    = 'Кодове за отстъпки';

// Text
$_['text_extension']   = 'Разширения';
$_['text_success']     = 'Готово: Променихте кодовете за отстъпки!';
$_['text_edit']        = 'Редактиране на кодове за отстъпки';

// Entry
$_['entry_coupon']     = 'Купон код';
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Подреждане';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте кодовете за отстъпки!';
