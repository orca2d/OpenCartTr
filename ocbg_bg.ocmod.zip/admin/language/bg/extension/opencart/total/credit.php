<?php
// Heading
$_['heading_title']    = 'Кредитиране';

// Text
$_['text_extension']   = 'Разширения';
$_['text_success']     = 'Готово: Променихте кредитирането!';
$_['text_edit']        = 'Редактиране на кредитиране';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Подреждане';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте кредитирането!';
