<?php
// Heading
$_['heading_title']    = 'Доставка';

// Text
$_['text_extension']   = 'Разширения';
$_['text_success']     = 'Готово: Променихте модула за доставка!';
$_['text_edit']        = 'Редактиране на модула за доставка';

// Entry
$_['entry_estimator']  = 'Изчисляване на доставка';
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Подреждане';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте модула за доставка!';
