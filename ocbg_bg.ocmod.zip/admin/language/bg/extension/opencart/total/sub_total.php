<?php
// Heading
$_['heading_title']    = 'Междинна сума';

// Text
$_['text_extension']   = 'Разширения';
$_['text_success']     = 'Готово: Променихте модула за междинна сума';
$_['text_edit']        = 'Редактиране на модул за междинна сума';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Подреждане';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте модула за междинна сума!';
