<?php
// Heading
$_['heading_title']    = 'Филтър';

// Text
$_['text_extension']   = 'Разширения';
$_['text_success']     = 'Готово: Променихте модула за филтър!';
$_['text_edit']        = 'Редактиране на филтър';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте модула за филтър!';
