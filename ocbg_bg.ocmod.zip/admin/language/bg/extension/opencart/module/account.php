<?php
// Heading
$_['heading_title']    = 'Профили';

// Text
$_['text_extension']   = 'Разширения';
$_['text_success']     = 'Готово: Променихте модула за профили!';
$_['text_edit']        = 'Редактиране на модул за профили';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте модула с профили!';
