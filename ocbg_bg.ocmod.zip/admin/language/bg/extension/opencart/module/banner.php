<?php
// Heading
$_['heading_title']    = 'Банери';

// Text
$_['text_extension']   = 'Разширения';
$_['text_success']     = 'Готово: Променихте модула за банери!';
$_['text_edit']        = 'Редактиране на банер модула';
$_['text_slide']       = 'Плъзване';
$_['text_fade']        = 'Преливане';

// Entry
$_['entry_name']       = 'Име на модула';
$_['entry_banner']     = 'Банер';
$_['entry_effect']     = 'Ефект';
$_['entry_items']      = 'Елементи на слайд';
$_['entry_controls']   = 'Контроли';
$_['entry_indicators'] = 'Индикатори';
$_['entry_interval']   = 'Интервал';
$_['entry_width']      = 'Ширина';
$_['entry_height']     = 'Височина';
$_['entry_status']     = 'Статус';

// Help
$_['help_items']       = 'Броя елеметни, които да се показват на слайд.';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте модула за банери!';
$_['error_name']       = 'Името на модула трябва да е между 3 и 64 символа!';
$_['error_interval']   = 'Необходим е интервал!';
$_['error_width']      = 'Необходима е ширина!';
$_['error_height']     = 'Необходима е височина!';