<?php
// Heading
$_['heading_title']    = 'Меню с категории';

// Text
$_['text_extension']   = 'Разширения';
$_['text_success']     = 'Готово: Променихте менюто с категории!';
$_['text_edit']        = 'Редактиране на менюто с категории';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте менюто с категории!';
