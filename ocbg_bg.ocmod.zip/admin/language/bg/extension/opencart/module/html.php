<?php
// Heading
$_['heading_title']     = 'HTML съдръжание';

// Text
$_['text_extension']    = 'Разширения';
$_['text_success']      = 'Готово: Променихте модула за HTML съдържание!';
$_['text_edit']         = 'Редактиране на модула за HTML съдържание';

// Entry
$_['entry_name']        = 'Име на модула';
$_['entry_title']       = 'Заглавие на модула';
$_['entry_description'] = 'Описание';
$_['entry_status']      = 'Статус';

// Error
$_['error_permission']  = 'Внимание: Нямате право да променяте модула за HTML съдържание!';
$_['error_name']        = 'Името на модула трябва да е между 3 и 64 символа!';