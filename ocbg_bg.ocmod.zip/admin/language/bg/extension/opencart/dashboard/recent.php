<?php
// Heading
$_['heading_title'] = 'Последни поръчки';

// Text
$_['text_extension'] = 'Разширения';
$_['text_success']   = 'Готово: Променихте таблото с последните поръчки!';
$_['text_edit']      = 'Редактиране на таблото с последните поръчки';

// Column
$_['column_order_id']   = 'Номер';
$_['column_customer']   = 'Клиент';
$_['column_status']     = 'Статус';
$_['column_total']      = 'Общо';
$_['column_date_added'] = 'Дата на добавяне';
$_['column_action']     = 'Действие';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Подреждане';
$_['entry_width']      = 'Ширина';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте таблото с последните поръчки!';
