<?php
// Heading
$_['heading_title'] = 'Последна активност';

// Text
$_['text_extension']               = 'Разширения';
$_['text_success']                 = 'Готово: Променихте таблото с активности!';
$_['text_edit']                    = 'Редактиране на таблото с активности';
$_['text_activity_register']       = '<a href="customer_id=%d">%s</a> регистрира нов профил.';
$_['text_activity_edit']           = '<a href="customer_id=%d">%s</a> актуализира информацията в профила си.';
$_['text_activity_password']       = '<a href="customer_id=%d">%s</a> актуализира паролата на профила си.';
$_['text_activity_reset']          = '<a href="customer_id=%d">%s</a> нулира паролата на профила си.';
$_['text_activity_login']          = '<a href="customer_id=%d">%s</a> влезна в профила си.';
$_['text_activity_forgotten']      = '<a href="customer_id=%d">%s</a> поиска нулиране на паролата си.';
$_['text_activity_address_add']    = '<a href="customer_id=%d">%s</a> добави нов адрес.';
$_['text_activity_address_edit']   = '<a href="customer_id=%d">%s</a> актуализира своя адрес.';
$_['text_activity_address_delete'] = '<a href="customer_id=%d">%s</a> изтри един от адресите си.';
$_['text_activity_return_account'] = '<a href="customer_id=%d">%s</a> изпрати заявка за  <a href="return_id=%d">връщане на продукт</a>.';
$_['text_activity_return_guest']   = '%s изпрати заявка за <a href="return_id=%d">връщане на продукт</a>.';
$_['text_activity_order_account']  = '<a href="customer_id=%d">%s</a> добави <a href="order_id=%d">нова поръчка</a>.';
$_['text_activity_order_guest']    = '%s създаде <a href="order_id=%d">нова поръчка</a>.';
$_['text_activity_affiliate_add']  = '<a href="customer_id=%d">%s</a> се регистрира за Афилиейт партньор.';
$_['text_activity_affiliate_edit'] = '<a href="customer_id=%d">%s</a> актуализира информацията в афилиейт профила си.';
$_['text_activity_transaction']    = '<a href="customer_id=%d">%s</a> получи комисионна за нова <a href="order_id=%d">поръчка</a>.';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Подреждане';
$_['entry_width']      = 'Ширина';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте таблото с активности!';
