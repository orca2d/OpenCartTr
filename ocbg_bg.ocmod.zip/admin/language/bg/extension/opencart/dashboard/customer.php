<?php
// Heading
$_['heading_title'] = 'Общо клиенти';

// Text
$_['text_extension'] = 'Разширения';
$_['text_success']   = 'Готово: Променихте таблото с клиенти!';
$_['text_edit']      = 'Редактиране на таблото с клиенти';
$_['text_view']      = 'Виж повече...';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Подреждане';
$_['entry_width']      = 'Ширина';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте таблото с клиенти!';
