<?php
// Heading
$_['heading_title'] = 'Анализ на продажбите';

// Text
$_['text_extension'] = 'Разширения';
$_['text_success']   = 'Готово: Променихте диаграмата на таблото!';
$_['text_edit']      = 'Редактиране на диаграмата на таблото';
$_['text_order']     = 'Поръчки';
$_['text_customer']  = 'Клиенти';
$_['text_day']       = 'Днес';
$_['text_week']      = 'Седмица';
$_['text_month']     = 'Месец';
$_['text_year']      = 'Година';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Подреждане';
$_['entry_width']      = 'Ширина';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте диаграмата на таблото!';
