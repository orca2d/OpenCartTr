<?php
// Heading
$_['heading_title'] = 'Световна карта';

// Text
$_['text_extension'] = 'Разширения';
$_['text_success']   = 'Готово: Променихте таблото с картата!';
$_['text_edit']      = 'Редактиране на таблото с картата';
$_['text_order']     = 'Поръчки';
$_['text_sale']      = 'Продажби';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Подреждане';
$_['entry_width']      = 'Ширина';

// Error
$_['error_permission'] = 'Внимание: Нямате право да променяте таблото с картата!';
