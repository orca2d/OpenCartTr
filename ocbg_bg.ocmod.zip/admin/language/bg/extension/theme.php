<?php
// Heading
$_['heading_title'] = 'Теми';

// Text
$_['text_success'] = 'Готово: Променихте темата!';

// Column
$_['column_name']   = 'Име на тема';
$_['column_status'] = 'Статус';
$_['column_action'] = 'Действие';

// Error
$_['error_permission'] = 'Внимание: Нямате права за промяна на темите!';
$_['error_extension']  = 'Внимание: Разширението не съществува!';
