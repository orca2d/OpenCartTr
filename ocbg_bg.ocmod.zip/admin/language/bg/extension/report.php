<?php
// Heading
$_['heading_title'] = 'Отчети';

// Text
$_['text_success'] = 'Готово: Променихте отчетите!';
$_['text_list']    = 'Списък с отчети';

// Column
$_['column_name']       = 'Име на отчет';
$_['column_status']     = 'Статус';
$_['column_sort_order'] = 'Подреждане';
$_['column_action']     = 'Действие';

// Error
$_['error_permission'] = 'Внимание: Нямате права за промяна на отчетите!';
$_['error_extension']  = 'Внимание: Разширението не съществува!';
