<?php
// Heading
$_['heading_title'] = 'Доставчици';

// Text
$_['text_success'] = 'Готово: Променихте доставчиците!';
$_['text_list']    = 'Списък с доставчици';

// Column
$_['column_name']       = 'Начин на доставка';
$_['column_status']     = 'Статус';
$_['column_sort_order'] = 'Подреждане';
$_['column_action']     = 'Действие';

// Error
$_['error_permission'] = 'Внимание: Нямате права за промяна на доставчиците!';
$_['error_extension']  = 'Внимание: Разширението не съществува!';
