<?php
// Heading
$_['heading_title'] = 'Други';

// Text
$_['text_success'] = 'Готово: Променихте другите разширения!';
$_['text_list']    = 'Списък с други';

// Column
$_['column_name']   = 'Други';
$_['column_status'] = 'Статус';
$_['column_action'] = 'Действие';

// Error
$_['error_permission'] = 'Внимание: Нямате права за промяна на секцията!';
$_['error_extension']  = 'Внимание: Разширението не съществува!';
