<?php
// Heading
$_['heading_title'] = 'Капчи';

// Text
$_['text_success'] = 'Готово: Променихте успешно капчите!';
$_['text_list']    = 'Списък с капчи';

// Column
$_['column_name']   = 'Име на капчата';
$_['column_status'] = 'Статус';
$_['column_action'] = 'Действие';

// Error
$_['error_permission'] = 'Внимание: Нямате права за промяна на капчите!';
$_['error_extension']  = 'Внимание: Разширението не съществува!';
