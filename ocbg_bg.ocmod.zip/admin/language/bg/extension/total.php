<?php
// Heading
$_['heading_title'] = 'Общи суми';

// Text
$_['text_success'] = 'Готово: Променихте общите суми!';

// Column
$_['column_name']       = 'Общи суми за поръчки';
$_['column_status']     = 'Статус';
$_['column_sort_order'] = 'Подреждане';
$_['column_action']     = 'Действие';

// Error
$_['error_permission'] = 'Внимание: Нямате права за промяна на общите суми!';
$_['error_extension']  = 'Внимание: Разширението не съществува!';