<?php
// Heading
$_['heading_title'] = 'Фийдове';

// Text
$_['text_success'] = 'Готово: Променихте фийдовете!';
$_['text_list']    = 'Списък с фийдове';

// Column
$_['column_name']   = 'Име на продуктовия фийд';
$_['column_status'] = 'Статус';
$_['column_action'] = 'Действие';

// Error
$_['error_permission'] = 'Внимание: Нямате права за промяна на фийдовете!';
$_['error_extension']  = 'Внимание: Разширението не съществува!';