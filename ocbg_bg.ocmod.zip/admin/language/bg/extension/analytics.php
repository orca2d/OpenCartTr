<?php
// Heading
$_['heading_title'] = 'Анализи';

// Text
$_['text_success'] = 'Готово: Променихте данните в анализи!';
$_['text_list']    = 'Списък с данни в анализи';

// Column
$_['column_name']   = 'Име на данните за анализи';
$_['column_status'] = 'Статус';
$_['column_action'] = 'Действие';

// Error
$_['error_permission'] = 'Внимание: Нямате права за промяна на данните в анализи!';
$_['error_extension']  = 'Внимание: Разширението не съществува!';