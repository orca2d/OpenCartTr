<?php

namespace Opencart\Admin\Controller\Extension\OcbgBg\Language;
/**
 * Class Bulgarian
 *
 * @package Opencart\Admin\Controller\Extension\OcbgBg
 */
class Bulgarian extends \Opencart\System\Engine\Controller
{
    public function index(): void
    {
        $this->load->language('extension/ocbg_bg/language/bulgarian');

        $this->document->setTitle($this->language->get('heading_title'));

        $data['breadcrumbs'] = [];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=language')
        ];

        $data['breadcrumbs'][] = [
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/ocbg_bg/language/bulgarian', 'user_token=' . $this->session->data['user_token'])
        ];

        $data['save'] = $this->url->link('extension/ocbg_bg/language/bulgarian|save', 'user_token=' . $this->session->data['user_token']);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=language');

        $data['language_bulgarian_status'] = $this->config->get('language_bulgarian_status');

        $data['header']      = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer']      = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/ocbg_bg/language/bulgarian', $data));
    }

    public function save(): void
    {
        $this->load->language('extension/ocbg_bg/language/bulgarian');

        $json = [];

        if (!$this->user->hasPermission('modify', 'extension/ocbg_bg/language/bulgarian')) {
            $json['error'] = $this->language->get('error_permission');
        }

        if (!$json) {
            $this->load->model('setting/setting');

            $this->model_setting_setting->editSetting('language_bulgarian', $this->request->post);

            $json['success'] = $this->language->get('text_success');
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    public function install(): void
    {
        if ($this->user->hasPermission('modify', 'extension/language')) {

            $language_info = $this->model_localisation_language->getLanguageByCode('bg');
            if (!$language_info) {
                // Add language
                $language_data = [
                    'name'       => 'Български',
                    'code'       => 'bg',
                    'locale'     => 'bg',
                    'extension'  => 'ocbg_bg',
                    'status'     => 1,
                    'sort_order' => 2
                ];

                $this->load->model('localisation/language');

                $this->model_localisation_language->addLanguage($language_data);

                @mail('info@opencartbulgaria.com', 'Bulgarian Language installed (v4.1.0.0)', HTTP_CATALOG . ' - ' . $this->config->get('config_name') . "\r\n" . 'version - ' . VERSION . "\r\n" . 'IP - ' . $this->request->server['REMOTE_ADDR'], 'MIME-Version: 1.0' . "\r\n" . 'Content-type: text/plain; charset=UTF-8' . "\r\n" . 'From: ' . $this->config->get('config_owner') . ' <' . $this->config->get('config_email') . '>' . "\r\n");
            } else {
                // Edit language
                $this->load->model('localisation/language');

                $this->model_localisation_language->editLanguage($language_info['language_id'], $language_info + ['extension' => 'ocbg_bg']);
            }

        }
    }

    public function uninstall(): void
    {
        if ($this->user->hasPermission('modify', 'extension/language')) {
            $this->load->model('localisation/language');

            $language_info = $this->model_localisation_language->getLanguageByCode('bg');

            if ($language_info) {
                $this->model_localisation_language->deleteLanguage($language_info['language_id']);
            }
        }
    }
}