<?php
// Text
$_['text_project']       = 'Начало';
$_['text_documentation'] = 'Документация';
$_['text_support']       = 'Форуми за поддръжка';
$_['text_footer']        = '<a href="https://opencartbulgaria.com" target="_blank">OpenCart България</a> &copy; 2020-' . date('Y') . ' Всички права запазени.';
