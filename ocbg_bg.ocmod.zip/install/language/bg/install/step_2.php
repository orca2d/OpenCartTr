<?php
// Heading
$_['heading_title'] = 'Предварителна инсталация';

// Text
$_['text_step_2']            = 'Проверете дали вашият сървър е настроен правилно';
$_['text_install_php']       = '1. Моля, конфигурирайте вашите PHP настройки, за да отговарят на изискванията, изброени по-долу.';
$_['text_install_extension'] = '2. Моля, уверете се, че следните PHP разширения са инсталирани.';
$_['text_install_file']      = '3. Моля, уверете се, че сте задали правилните разрешения(права) на следните файлове.';
$_['text_setting']           = 'PHP настройки';
$_['text_current']           = 'Текущи настройки';
$_['text_required']          = 'Задължителни настройки';
$_['text_extension']         = 'Настройки на разширенията';
$_['text_db']                = 'База данни';
$_['text_version']           = 'PHP версия';
$_['text_global']            = 'Регистриране на глобални променливи';
$_['text_magic']             = 'Магически кавички GPC';
$_['text_file_upload']       = 'Качване на файлове';
$_['text_session']           = 'Автоматично стартиране на сесията';
$_['text_gd']                = 'GD';
$_['text_curl']              = 'cURL';
$_['text_openssl']           = 'OpenSSL';
$_['text_zlib']              = 'ZLIB';
$_['text_zip']               = 'ZIP';
$_['text_mbstring']          = 'mbstring';
$_['text_on']                = 'Включено';
$_['text_off']               = 'Изключено';
$_['text_file']              = 'Файлове';
$_['text_status']            = 'Статус';
$_['text_writable']          = 'С права за запис';
$_['text_unwritable']        = 'Без права за запис';
$_['text_missing']           = 'Липсва';

// Error
$_['error_version']          = 'Внимание: За работата на OpenCart е необходима версия на PHP 7.4 или по-нова!';
$_['error_file_upload']      = 'Внимание: file_uploads трябва да е активирано!';
$_['error_session']          = 'Внимание: OpenCart няма да работи, ако session.auto_start е активиран!';
$_['error_db']               = 'Внимание: Необходимо е да се зареди разширение за база данни в php.ini файла, за да работи OpenCart!';
$_['error_gd']               = 'Внимание: За работата на OpenCart е необходимо да се зареди разширението GD!';
$_['error_curl']             = 'Внимание: За работата на OpenCart е необходимо да се зареди разширението CURL!';
$_['error_openssl']          = 'Внимание: За работата на OpenCart е необходимо да се зареди разширението OpenSSL!';
$_['error_zlib']             = 'Внимание: За работата на OpenCart е необходимо да се зареди разширението ZLIB!';
$_['error_zip']              = 'Внимание: За работата на OpenCart е необходимо да се зареди разширението ZIP!';
$_['error_mbstring']         = 'Внимание: За работата на OpenCart е необходимо да се зареди разширението mbstring!';
$_['error_catalog_exist']    = 'Внимание: Файлът config.php не съществува. Трябва да преименувате config-dist.php на config.php!';
$_['error_catalog_writable'] = 'Внимание: За да се инсталира OpenCart, config.php трябва да има права за запис!';
$_['error_admin_exist']      = 'Внимание: Файлът admin/config.php не съществува. Необходимо е да преименувате admin/config-dist.php на admin/config.php!';
$_['error_admin_writable']   = 'Внимание: За да се инсталира OpenCart, admin/config.php трябва да има права за запис!';
