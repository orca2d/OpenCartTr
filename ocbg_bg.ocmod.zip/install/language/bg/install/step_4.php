<?php
// Heading
$_['heading_title'] = 'Успешна инсталация';

// Text
$_['text_step_4']                 = 'Вече имате онлайн магазин!';
$_['text_catalog']                = 'Посетете онлайн магазина';
$_['text_admin']                  = 'Влезте админ панела';
$_['text_extension']              = 'Отидете в маркетплейса';
$_['text_mail']                   = 'Абонирайте се за бюлетин';
$_['text_mail_description']       = 'Бъдете в час с новостите и събитията в OpenCart.';
$_['text_facebook']               = 'Станете наш последовател във Facebook';
$_['text_facebook_description']   = 'Споделете с нас вашето мнение за OpenCart!';
$_['text_facebook_visit']         = 'Посетете нашата страница във Facebook';
$_['text_forum']                  = 'Обществени форуми';
$_['text_forum_description']      = 'Потърсете помощ от други потребители на OpenCart';
$_['text_forum_visit']            = 'Посетете нашите форуми';
$_['text_commercial']             = 'Търговска поддръжка';
$_['text_commercial_description'] = 'Намерете OpenCart партньори за вашите нужди за разработка';
$_['text_commercial_visit']       = 'Посетете нашата страница с партньори';

// Button
$_['button_mail'] = 'Присъединете се тук';

// Error
$_['error_warning'] = 'Не забравяйте да изтриете инсталационната папка на OpenCart!';
