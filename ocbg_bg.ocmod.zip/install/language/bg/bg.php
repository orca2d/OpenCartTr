<?php
// Text
$_['text_name']    = 'Български';
$_['text_loading'] = 'Зареждане...';

// Button
$_['button_continue'] = 'Продължи';
$_['button_back']     = 'Назад';

// Error
$_['error_exception'] = 'Код за грешка(%s): %s в %s на ред %s';
